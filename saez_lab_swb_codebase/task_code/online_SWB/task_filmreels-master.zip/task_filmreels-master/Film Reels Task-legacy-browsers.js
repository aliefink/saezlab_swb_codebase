﻿/************************ 
 * Film Reels Task *
 ************************/


// store info about the experiment session:
let expName = 'Film Reels Task';  // from the Builder filename that created this script
let expInfo = {
    '--': 'Please wait while the study loads (roughly 1-2 minutes)',
    'prolific_id': '',
    'study_id': '',
    'session_id': '',
};

// Start code blocks for 'Before Experiment'
util.addInfoFromUrl(expInfo);
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0,0,0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(exp_startRoutineBegin());
flowScheduler.add(exp_startRoutineEachFrame());
flowScheduler.add(exp_startRoutineEnd());
flowScheduler.add(consentRoutineBegin());
flowScheduler.add(consentRoutineEachFrame());
flowScheduler.add(consentRoutineEnd());
flowScheduler.add(instructionsRoutineBegin());
flowScheduler.add(instructionsRoutineEachFrame());
flowScheduler.add(instructionsRoutineEnd());
flowScheduler.add(prac_startRoutineBegin());
flowScheduler.add(prac_startRoutineEachFrame());
flowScheduler.add(prac_startRoutineEnd());
const prac_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(prac_loopLoopBegin(prac_loopLoopScheduler));
flowScheduler.add(prac_loopLoopScheduler);
flowScheduler.add(prac_loopLoopEnd);











flowScheduler.add(quizInstrRoutineBegin());
flowScheduler.add(quizInstrRoutineEachFrame());
flowScheduler.add(quizInstrRoutineEnd());
const quiz_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(quiz_loopLoopBegin(quiz_loopLoopScheduler));
flowScheduler.add(quiz_loopLoopScheduler);
flowScheduler.add(quiz_loopLoopEnd);



flowScheduler.add(get_readyRoutineBegin());
flowScheduler.add(get_readyRoutineEachFrame());
flowScheduler.add(get_readyRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);






















flowScheduler.add(exp_endRoutineBegin());
flowScheduler.add(exp_endRoutineEachFrame());
flowScheduler.add(exp_endRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
    {'name': 'prac_orders.csv', 'path': 'prac_orders.csv'},
    {'name': 'stimuli/practice/prac_filmreel_A.png', 'path': 'stimuli/practice/prac_filmreel_A.png'},
    {'name': 'stimuli/practice/prac_filmreel_B.png', 'path': 'stimuli/practice/prac_filmreel_B.png'},
    {'name': 'stimuli/blank.jpg', 'path': 'stimuli/blank.jpg'},
    {'name': 'stimuli/practice/pexels-photo-2082090.jpeg', 'path': 'stimuli/practice/pexels-photo-2082090.jpeg'},
    {'name': 'stimuli/practice/pexels-photo-3705539.jpeg', 'path': 'stimuli/practice/pexels-photo-3705539.jpeg'},
    {'name': 'quiz.csv', 'path': 'quiz.csv'},
    {'name': 'default.png', 'path': 'https://pavlovia.org/assets/default/default.png'},
    {'name': 'stimuli/frame.png', 'path': 'stimuli/frame.png'},
    {'name': 'orders/sub-5114_task-filmreels_orders.csv', 'path': 'orders/sub-5114_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5115_task-filmreels_orders.csv', 'path': 'orders/sub-5115_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5116_task-filmreels_orders.csv', 'path': 'orders/sub-5116_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5117_task-filmreels_orders.csv', 'path': 'orders/sub-5117_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5118_task-filmreels_orders.csv', 'path': 'orders/sub-5118_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5119_task-filmreels_orders.csv', 'path': 'orders/sub-5119_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5120_task-filmreels_orders.csv', 'path': 'orders/sub-5120_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5121_task-filmreels_orders.csv', 'path': 'orders/sub-5121_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5122_task-filmreels_orders.csv', 'path': 'orders/sub-5122_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5123_task-filmreels_orders.csv', 'path': 'orders/sub-5123_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5124_task-filmreels_orders.csv', 'path': 'orders/sub-5124_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5125_task-filmreels_orders.csv', 'path': 'orders/sub-5125_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5126_task-filmreels_orders.csv', 'path': 'orders/sub-5126_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5127_task-filmreels_orders.csv', 'path': 'orders/sub-5127_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5128_task-filmreels_orders.csv', 'path': 'orders/sub-5128_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5129_task-filmreels_orders.csv', 'path': 'orders/sub-5129_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5130_task-filmreels_orders.csv', 'path': 'orders/sub-5130_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5131_task-filmreels_orders.csv', 'path': 'orders/sub-5131_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5132_task-filmreels_orders.csv', 'path': 'orders/sub-5132_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5133_task-filmreels_orders.csv', 'path': 'orders/sub-5133_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5134_task-filmreels_orders.csv', 'path': 'orders/sub-5134_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5135_task-filmreels_orders.csv', 'path': 'orders/sub-5135_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5136_task-filmreels_orders.csv', 'path': 'orders/sub-5136_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5137_task-filmreels_orders.csv', 'path': 'orders/sub-5137_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5138_task-filmreels_orders.csv', 'path': 'orders/sub-5138_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5139_task-filmreels_orders.csv', 'path': 'orders/sub-5139_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5140_task-filmreels_orders.csv', 'path': 'orders/sub-5140_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5141_task-filmreels_orders.csv', 'path': 'orders/sub-5141_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5142_task-filmreels_orders.csv', 'path': 'orders/sub-5142_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5143_task-filmreels_orders.csv', 'path': 'orders/sub-5143_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5144_task-filmreels_orders.csv', 'path': 'orders/sub-5144_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5145_task-filmreels_orders.csv', 'path': 'orders/sub-5145_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5146_task-filmreels_orders.csv', 'path': 'orders/sub-5146_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5147_task-filmreels_orders.csv', 'path': 'orders/sub-5147_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5148_task-filmreels_orders.csv', 'path': 'orders/sub-5148_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5149_task-filmreels_orders.csv', 'path': 'orders/sub-5149_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5150_task-filmreels_orders.csv', 'path': 'orders/sub-5150_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5151_task-filmreels_orders.csv', 'path': 'orders/sub-5151_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5152_task-filmreels_orders.csv', 'path': 'orders/sub-5152_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5153_task-filmreels_orders.csv', 'path': 'orders/sub-5153_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5154_task-filmreels_orders.csv', 'path': 'orders/sub-5154_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5155_task-filmreels_orders.csv', 'path': 'orders/sub-5155_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5156_task-filmreels_orders.csv', 'path': 'orders/sub-5156_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5157_task-filmreels_orders.csv', 'path': 'orders/sub-5157_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5158_task-filmreels_orders.csv', 'path': 'orders/sub-5158_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5159_task-filmreels_orders.csv', 'path': 'orders/sub-5159_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5160_task-filmreels_orders.csv', 'path': 'orders/sub-5160_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5161_task-filmreels_orders.csv', 'path': 'orders/sub-5161_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5162_task-filmreels_orders.csv', 'path': 'orders/sub-5162_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5163_task-filmreels_orders.csv', 'path': 'orders/sub-5163_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5164_task-filmreels_orders.csv', 'path': 'orders/sub-5164_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5165_task-filmreels_orders.csv', 'path': 'orders/sub-5165_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5166_task-filmreels_orders.csv', 'path': 'orders/sub-5166_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5167_task-filmreels_orders.csv', 'path': 'orders/sub-5167_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5168_task-filmreels_orders.csv', 'path': 'orders/sub-5168_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5169_task-filmreels_orders.csv', 'path': 'orders/sub-5169_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5170_task-filmreels_orders.csv', 'path': 'orders/sub-5170_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5171_task-filmreels_orders.csv', 'path': 'orders/sub-5171_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5172_task-filmreels_orders.csv', 'path': 'orders/sub-5172_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5173_task-filmreels_orders.csv', 'path': 'orders/sub-5173_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5174_task-filmreels_orders.csv', 'path': 'orders/sub-5174_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5175_task-filmreels_orders.csv', 'path': 'orders/sub-5175_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5176_task-filmreels_orders.csv', 'path': 'orders/sub-5176_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5177_task-filmreels_orders.csv', 'path': 'orders/sub-5177_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5178_task-filmreels_orders.csv', 'path': 'orders/sub-5178_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5179_task-filmreels_orders.csv', 'path': 'orders/sub-5179_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5180_task-filmreels_orders.csv', 'path': 'orders/sub-5180_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5181_task-filmreels_orders.csv', 'path': 'orders/sub-5181_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5182_task-filmreels_orders.csv', 'path': 'orders/sub-5182_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5183_task-filmreels_orders.csv', 'path': 'orders/sub-5183_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5184_task-filmreels_orders.csv', 'path': 'orders/sub-5184_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5185_task-filmreels_orders.csv', 'path': 'orders/sub-5185_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5186_task-filmreels_orders.csv', 'path': 'orders/sub-5186_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5187_task-filmreels_orders.csv', 'path': 'orders/sub-5187_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5188_task-filmreels_orders.csv', 'path': 'orders/sub-5188_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5189_task-filmreels_orders.csv', 'path': 'orders/sub-5189_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5190_task-filmreels_orders.csv', 'path': 'orders/sub-5190_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5191_task-filmreels_orders.csv', 'path': 'orders/sub-5191_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5192_task-filmreels_orders.csv', 'path': 'orders/sub-5192_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5193_task-filmreels_orders.csv', 'path': 'orders/sub-5193_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5194_task-filmreels_orders.csv', 'path': 'orders/sub-5194_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5195_task-filmreels_orders.csv', 'path': 'orders/sub-5195_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5196_task-filmreels_orders.csv', 'path': 'orders/sub-5196_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5197_task-filmreels_orders.csv', 'path': 'orders/sub-5197_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5198_task-filmreels_orders.csv', 'path': 'orders/sub-5198_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5199_task-filmreels_orders.csv', 'path': 'orders/sub-5199_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5200_task-filmreels_orders.csv', 'path': 'orders/sub-5200_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5201_task-filmreels_orders.csv', 'path': 'orders/sub-5201_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5202_task-filmreels_orders.csv', 'path': 'orders/sub-5202_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5203_task-filmreels_orders.csv', 'path': 'orders/sub-5203_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5204_task-filmreels_orders.csv', 'path': 'orders/sub-5204_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5205_task-filmreels_orders.csv', 'path': 'orders/sub-5205_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5206_task-filmreels_orders.csv', 'path': 'orders/sub-5206_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5207_task-filmreels_orders.csv', 'path': 'orders/sub-5207_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5208_task-filmreels_orders.csv', 'path': 'orders/sub-5208_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5209_task-filmreels_orders.csv', 'path': 'orders/sub-5209_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5210_task-filmreels_orders.csv', 'path': 'orders/sub-5210_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5211_task-filmreels_orders.csv', 'path': 'orders/sub-5211_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5212_task-filmreels_orders.csv', 'path': 'orders/sub-5212_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5213_task-filmreels_orders.csv', 'path': 'orders/sub-5213_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5214_task-filmreels_orders.csv', 'path': 'orders/sub-5214_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5215_task-filmreels_orders.csv', 'path': 'orders/sub-5215_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5216_task-filmreels_orders.csv', 'path': 'orders/sub-5216_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5217_task-filmreels_orders.csv', 'path': 'orders/sub-5217_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5218_task-filmreels_orders.csv', 'path': 'orders/sub-5218_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5219_task-filmreels_orders.csv', 'path': 'orders/sub-5219_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5220_task-filmreels_orders.csv', 'path': 'orders/sub-5220_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5221_task-filmreels_orders.csv', 'path': 'orders/sub-5221_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5222_task-filmreels_orders.csv', 'path': 'orders/sub-5222_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5223_task-filmreels_orders.csv', 'path': 'orders/sub-5223_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5224_task-filmreels_orders.csv', 'path': 'orders/sub-5224_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5225_task-filmreels_orders.csv', 'path': 'orders/sub-5225_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5226_task-filmreels_orders.csv', 'path': 'orders/sub-5226_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5227_task-filmreels_orders.csv', 'path': 'orders/sub-5227_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5228_task-filmreels_orders.csv', 'path': 'orders/sub-5228_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5229_task-filmreels_orders.csv', 'path': 'orders/sub-5229_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5230_task-filmreels_orders.csv', 'path': 'orders/sub-5230_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5231_task-filmreels_orders.csv', 'path': 'orders/sub-5231_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5232_task-filmreels_orders.csv', 'path': 'orders/sub-5232_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5233_task-filmreels_orders.csv', 'path': 'orders/sub-5233_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5234_task-filmreels_orders.csv', 'path': 'orders/sub-5234_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5235_task-filmreels_orders.csv', 'path': 'orders/sub-5235_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5236_task-filmreels_orders.csv', 'path': 'orders/sub-5236_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5237_task-filmreels_orders.csv', 'path': 'orders/sub-5237_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5238_task-filmreels_orders.csv', 'path': 'orders/sub-5238_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5239_task-filmreels_orders.csv', 'path': 'orders/sub-5239_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5240_task-filmreels_orders.csv', 'path': 'orders/sub-5240_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5241_task-filmreels_orders.csv', 'path': 'orders/sub-5241_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5242_task-filmreels_orders.csv', 'path': 'orders/sub-5242_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5243_task-filmreels_orders.csv', 'path': 'orders/sub-5243_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5244_task-filmreels_orders.csv', 'path': 'orders/sub-5244_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5245_task-filmreels_orders.csv', 'path': 'orders/sub-5245_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5246_task-filmreels_orders.csv', 'path': 'orders/sub-5246_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5247_task-filmreels_orders.csv', 'path': 'orders/sub-5247_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5248_task-filmreels_orders.csv', 'path': 'orders/sub-5248_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5249_task-filmreels_orders.csv', 'path': 'orders/sub-5249_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5250_task-filmreels_orders.csv', 'path': 'orders/sub-5250_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5251_task-filmreels_orders.csv', 'path': 'orders/sub-5251_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5252_task-filmreels_orders.csv', 'path': 'orders/sub-5252_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5253_task-filmreels_orders.csv', 'path': 'orders/sub-5253_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5254_task-filmreels_orders.csv', 'path': 'orders/sub-5254_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5255_task-filmreels_orders.csv', 'path': 'orders/sub-5255_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5256_task-filmreels_orders.csv', 'path': 'orders/sub-5256_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5257_task-filmreels_orders.csv', 'path': 'orders/sub-5257_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5258_task-filmreels_orders.csv', 'path': 'orders/sub-5258_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5259_task-filmreels_orders.csv', 'path': 'orders/sub-5259_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5260_task-filmreels_orders.csv', 'path': 'orders/sub-5260_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5261_task-filmreels_orders.csv', 'path': 'orders/sub-5261_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5262_task-filmreels_orders.csv', 'path': 'orders/sub-5262_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5263_task-filmreels_orders.csv', 'path': 'orders/sub-5263_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5264_task-filmreels_orders.csv', 'path': 'orders/sub-5264_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5265_task-filmreels_orders.csv', 'path': 'orders/sub-5265_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5266_task-filmreels_orders.csv', 'path': 'orders/sub-5266_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5267_task-filmreels_orders.csv', 'path': 'orders/sub-5267_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5268_task-filmreels_orders.csv', 'path': 'orders/sub-5268_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5269_task-filmreels_orders.csv', 'path': 'orders/sub-5269_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5270_task-filmreels_orders.csv', 'path': 'orders/sub-5270_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5271_task-filmreels_orders.csv', 'path': 'orders/sub-5271_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5272_task-filmreels_orders.csv', 'path': 'orders/sub-5272_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5273_task-filmreels_orders.csv', 'path': 'orders/sub-5273_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5274_task-filmreels_orders.csv', 'path': 'orders/sub-5274_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5275_task-filmreels_orders.csv', 'path': 'orders/sub-5275_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5276_task-filmreels_orders.csv', 'path': 'orders/sub-5276_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5277_task-filmreels_orders.csv', 'path': 'orders/sub-5277_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5278_task-filmreels_orders.csv', 'path': 'orders/sub-5278_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5279_task-filmreels_orders.csv', 'path': 'orders/sub-5279_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5280_task-filmreels_orders.csv', 'path': 'orders/sub-5280_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5281_task-filmreels_orders.csv', 'path': 'orders/sub-5281_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5282_task-filmreels_orders.csv', 'path': 'orders/sub-5282_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5283_task-filmreels_orders.csv', 'path': 'orders/sub-5283_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5284_task-filmreels_orders.csv', 'path': 'orders/sub-5284_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5285_task-filmreels_orders.csv', 'path': 'orders/sub-5285_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5286_task-filmreels_orders.csv', 'path': 'orders/sub-5286_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5287_task-filmreels_orders.csv', 'path': 'orders/sub-5287_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5288_task-filmreels_orders.csv', 'path': 'orders/sub-5288_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5289_task-filmreels_orders.csv', 'path': 'orders/sub-5289_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5290_task-filmreels_orders.csv', 'path': 'orders/sub-5290_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5291_task-filmreels_orders.csv', 'path': 'orders/sub-5291_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5292_task-filmreels_orders.csv', 'path': 'orders/sub-5292_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5293_task-filmreels_orders.csv', 'path': 'orders/sub-5293_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5294_task-filmreels_orders.csv', 'path': 'orders/sub-5294_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5295_task-filmreels_orders.csv', 'path': 'orders/sub-5295_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5296_task-filmreels_orders.csv', 'path': 'orders/sub-5296_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5297_task-filmreels_orders.csv', 'path': 'orders/sub-5297_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5298_task-filmreels_orders.csv', 'path': 'orders/sub-5298_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5299_task-filmreels_orders.csv', 'path': 'orders/sub-5299_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5300_task-filmreels_orders.csv', 'path': 'orders/sub-5300_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5301_task-filmreels_orders.csv', 'path': 'orders/sub-5301_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5302_task-filmreels_orders.csv', 'path': 'orders/sub-5302_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5303_task-filmreels_orders.csv', 'path': 'orders/sub-5303_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5304_task-filmreels_orders.csv', 'path': 'orders/sub-5304_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5305_task-filmreels_orders.csv', 'path': 'orders/sub-5305_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5306_task-filmreels_orders.csv', 'path': 'orders/sub-5306_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5307_task-filmreels_orders.csv', 'path': 'orders/sub-5307_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5308_task-filmreels_orders.csv', 'path': 'orders/sub-5308_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5309_task-filmreels_orders.csv', 'path': 'orders/sub-5309_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5310_task-filmreels_orders.csv', 'path': 'orders/sub-5310_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5311_task-filmreels_orders.csv', 'path': 'orders/sub-5311_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5312_task-filmreels_orders.csv', 'path': 'orders/sub-5312_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5313_task-filmreels_orders.csv', 'path': 'orders/sub-5313_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5314_task-filmreels_orders.csv', 'path': 'orders/sub-5314_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5315_task-filmreels_orders.csv', 'path': 'orders/sub-5315_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5316_task-filmreels_orders.csv', 'path': 'orders/sub-5316_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5317_task-filmreels_orders.csv', 'path': 'orders/sub-5317_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5318_task-filmreels_orders.csv', 'path': 'orders/sub-5318_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5319_task-filmreels_orders.csv', 'path': 'orders/sub-5319_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5320_task-filmreels_orders.csv', 'path': 'orders/sub-5320_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5321_task-filmreels_orders.csv', 'path': 'orders/sub-5321_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5322_task-filmreels_orders.csv', 'path': 'orders/sub-5322_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5323_task-filmreels_orders.csv', 'path': 'orders/sub-5323_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5324_task-filmreels_orders.csv', 'path': 'orders/sub-5324_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5325_task-filmreels_orders.csv', 'path': 'orders/sub-5325_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5326_task-filmreels_orders.csv', 'path': 'orders/sub-5326_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5327_task-filmreels_orders.csv', 'path': 'orders/sub-5327_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5328_task-filmreels_orders.csv', 'path': 'orders/sub-5328_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5329_task-filmreels_orders.csv', 'path': 'orders/sub-5329_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5330_task-filmreels_orders.csv', 'path': 'orders/sub-5330_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5331_task-filmreels_orders.csv', 'path': 'orders/sub-5331_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5332_task-filmreels_orders.csv', 'path': 'orders/sub-5332_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5333_task-filmreels_orders.csv', 'path': 'orders/sub-5333_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5334_task-filmreels_orders.csv', 'path': 'orders/sub-5334_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5335_task-filmreels_orders.csv', 'path': 'orders/sub-5335_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5336_task-filmreels_orders.csv', 'path': 'orders/sub-5336_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5337_task-filmreels_orders.csv', 'path': 'orders/sub-5337_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5338_task-filmreels_orders.csv', 'path': 'orders/sub-5338_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5339_task-filmreels_orders.csv', 'path': 'orders/sub-5339_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5340_task-filmreels_orders.csv', 'path': 'orders/sub-5340_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5341_task-filmreels_orders.csv', 'path': 'orders/sub-5341_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5342_task-filmreels_orders.csv', 'path': 'orders/sub-5342_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5343_task-filmreels_orders.csv', 'path': 'orders/sub-5343_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5344_task-filmreels_orders.csv', 'path': 'orders/sub-5344_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5345_task-filmreels_orders.csv', 'path': 'orders/sub-5345_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5346_task-filmreels_orders.csv', 'path': 'orders/sub-5346_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5347_task-filmreels_orders.csv', 'path': 'orders/sub-5347_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5348_task-filmreels_orders.csv', 'path': 'orders/sub-5348_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5349_task-filmreels_orders.csv', 'path': 'orders/sub-5349_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5350_task-filmreels_orders.csv', 'path': 'orders/sub-5350_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5351_task-filmreels_orders.csv', 'path': 'orders/sub-5351_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5352_task-filmreels_orders.csv', 'path': 'orders/sub-5352_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5353_task-filmreels_orders.csv', 'path': 'orders/sub-5353_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5354_task-filmreels_orders.csv', 'path': 'orders/sub-5354_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5355_task-filmreels_orders.csv', 'path': 'orders/sub-5355_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5356_task-filmreels_orders.csv', 'path': 'orders/sub-5356_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5357_task-filmreels_orders.csv', 'path': 'orders/sub-5357_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5358_task-filmreels_orders.csv', 'path': 'orders/sub-5358_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5359_task-filmreels_orders.csv', 'path': 'orders/sub-5359_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5360_task-filmreels_orders.csv', 'path': 'orders/sub-5360_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5361_task-filmreels_orders.csv', 'path': 'orders/sub-5361_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5362_task-filmreels_orders.csv', 'path': 'orders/sub-5362_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5363_task-filmreels_orders.csv', 'path': 'orders/sub-5363_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5364_task-filmreels_orders.csv', 'path': 'orders/sub-5364_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5365_task-filmreels_orders.csv', 'path': 'orders/sub-5365_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5366_task-filmreels_orders.csv', 'path': 'orders/sub-5366_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5367_task-filmreels_orders.csv', 'path': 'orders/sub-5367_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5368_task-filmreels_orders.csv', 'path': 'orders/sub-5368_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5369_task-filmreels_orders.csv', 'path': 'orders/sub-5369_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5370_task-filmreels_orders.csv', 'path': 'orders/sub-5370_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5371_task-filmreels_orders.csv', 'path': 'orders/sub-5371_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5372_task-filmreels_orders.csv', 'path': 'orders/sub-5372_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5373_task-filmreels_orders.csv', 'path': 'orders/sub-5373_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5374_task-filmreels_orders.csv', 'path': 'orders/sub-5374_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5375_task-filmreels_orders.csv', 'path': 'orders/sub-5375_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5376_task-filmreels_orders.csv', 'path': 'orders/sub-5376_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5377_task-filmreels_orders.csv', 'path': 'orders/sub-5377_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5378_task-filmreels_orders.csv', 'path': 'orders/sub-5378_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5379_task-filmreels_orders.csv', 'path': 'orders/sub-5379_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5380_task-filmreels_orders.csv', 'path': 'orders/sub-5380_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5381_task-filmreels_orders.csv', 'path': 'orders/sub-5381_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5382_task-filmreels_orders.csv', 'path': 'orders/sub-5382_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5383_task-filmreels_orders.csv', 'path': 'orders/sub-5383_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5384_task-filmreels_orders.csv', 'path': 'orders/sub-5384_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5385_task-filmreels_orders.csv', 'path': 'orders/sub-5385_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5386_task-filmreels_orders.csv', 'path': 'orders/sub-5386_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5387_task-filmreels_orders.csv', 'path': 'orders/sub-5387_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5388_task-filmreels_orders.csv', 'path': 'orders/sub-5388_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5389_task-filmreels_orders.csv', 'path': 'orders/sub-5389_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5390_task-filmreels_orders.csv', 'path': 'orders/sub-5390_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5391_task-filmreels_orders.csv', 'path': 'orders/sub-5391_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5392_task-filmreels_orders.csv', 'path': 'orders/sub-5392_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5393_task-filmreels_orders.csv', 'path': 'orders/sub-5393_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5394_task-filmreels_orders.csv', 'path': 'orders/sub-5394_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5395_task-filmreels_orders.csv', 'path': 'orders/sub-5395_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5396_task-filmreels_orders.csv', 'path': 'orders/sub-5396_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5397_task-filmreels_orders.csv', 'path': 'orders/sub-5397_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5398_task-filmreels_orders.csv', 'path': 'orders/sub-5398_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5399_task-filmreels_orders.csv', 'path': 'orders/sub-5399_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5400_task-filmreels_orders.csv', 'path': 'orders/sub-5400_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5401_task-filmreels_orders.csv', 'path': 'orders/sub-5401_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5402_task-filmreels_orders.csv', 'path': 'orders/sub-5402_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5403_task-filmreels_orders.csv', 'path': 'orders/sub-5403_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5404_task-filmreels_orders.csv', 'path': 'orders/sub-5404_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5405_task-filmreels_orders.csv', 'path': 'orders/sub-5405_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5406_task-filmreels_orders.csv', 'path': 'orders/sub-5406_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5407_task-filmreels_orders.csv', 'path': 'orders/sub-5407_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5408_task-filmreels_orders.csv', 'path': 'orders/sub-5408_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5409_task-filmreels_orders.csv', 'path': 'orders/sub-5409_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5410_task-filmreels_orders.csv', 'path': 'orders/sub-5410_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5411_task-filmreels_orders.csv', 'path': 'orders/sub-5411_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5412_task-filmreels_orders.csv', 'path': 'orders/sub-5412_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5413_task-filmreels_orders.csv', 'path': 'orders/sub-5413_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5414_task-filmreels_orders.csv', 'path': 'orders/sub-5414_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5415_task-filmreels_orders.csv', 'path': 'orders/sub-5415_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5416_task-filmreels_orders.csv', 'path': 'orders/sub-5416_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5417_task-filmreels_orders.csv', 'path': 'orders/sub-5417_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5418_task-filmreels_orders.csv', 'path': 'orders/sub-5418_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5419_task-filmreels_orders.csv', 'path': 'orders/sub-5419_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5420_task-filmreels_orders.csv', 'path': 'orders/sub-5420_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5421_task-filmreels_orders.csv', 'path': 'orders/sub-5421_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5422_task-filmreels_orders.csv', 'path': 'orders/sub-5422_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5423_task-filmreels_orders.csv', 'path': 'orders/sub-5423_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5424_task-filmreels_orders.csv', 'path': 'orders/sub-5424_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5425_task-filmreels_orders.csv', 'path': 'orders/sub-5425_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5426_task-filmreels_orders.csv', 'path': 'orders/sub-5426_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5427_task-filmreels_orders.csv', 'path': 'orders/sub-5427_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5428_task-filmreels_orders.csv', 'path': 'orders/sub-5428_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5429_task-filmreels_orders.csv', 'path': 'orders/sub-5429_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5430_task-filmreels_orders.csv', 'path': 'orders/sub-5430_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5431_task-filmreels_orders.csv', 'path': 'orders/sub-5431_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5432_task-filmreels_orders.csv', 'path': 'orders/sub-5432_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5433_task-filmreels_orders.csv', 'path': 'orders/sub-5433_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5434_task-filmreels_orders.csv', 'path': 'orders/sub-5434_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5435_task-filmreels_orders.csv', 'path': 'orders/sub-5435_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5436_task-filmreels_orders.csv', 'path': 'orders/sub-5436_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5437_task-filmreels_orders.csv', 'path': 'orders/sub-5437_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5438_task-filmreels_orders.csv', 'path': 'orders/sub-5438_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5439_task-filmreels_orders.csv', 'path': 'orders/sub-5439_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5440_task-filmreels_orders.csv', 'path': 'orders/sub-5440_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5441_task-filmreels_orders.csv', 'path': 'orders/sub-5441_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5442_task-filmreels_orders.csv', 'path': 'orders/sub-5442_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5443_task-filmreels_orders.csv', 'path': 'orders/sub-5443_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5444_task-filmreels_orders.csv', 'path': 'orders/sub-5444_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5445_task-filmreels_orders.csv', 'path': 'orders/sub-5445_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5446_task-filmreels_orders.csv', 'path': 'orders/sub-5446_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5447_task-filmreels_orders.csv', 'path': 'orders/sub-5447_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5448_task-filmreels_orders.csv', 'path': 'orders/sub-5448_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5449_task-filmreels_orders.csv', 'path': 'orders/sub-5449_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5450_task-filmreels_orders.csv', 'path': 'orders/sub-5450_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5451_task-filmreels_orders.csv', 'path': 'orders/sub-5451_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5452_task-filmreels_orders.csv', 'path': 'orders/sub-5452_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5453_task-filmreels_orders.csv', 'path': 'orders/sub-5453_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5454_task-filmreels_orders.csv', 'path': 'orders/sub-5454_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5455_task-filmreels_orders.csv', 'path': 'orders/sub-5455_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5456_task-filmreels_orders.csv', 'path': 'orders/sub-5456_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5457_task-filmreels_orders.csv', 'path': 'orders/sub-5457_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5458_task-filmreels_orders.csv', 'path': 'orders/sub-5458_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5459_task-filmreels_orders.csv', 'path': 'orders/sub-5459_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5460_task-filmreels_orders.csv', 'path': 'orders/sub-5460_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5461_task-filmreels_orders.csv', 'path': 'orders/sub-5461_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5462_task-filmreels_orders.csv', 'path': 'orders/sub-5462_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5463_task-filmreels_orders.csv', 'path': 'orders/sub-5463_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5464_task-filmreels_orders.csv', 'path': 'orders/sub-5464_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5465_task-filmreels_orders.csv', 'path': 'orders/sub-5465_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5466_task-filmreels_orders.csv', 'path': 'orders/sub-5466_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5467_task-filmreels_orders.csv', 'path': 'orders/sub-5467_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5468_task-filmreels_orders.csv', 'path': 'orders/sub-5468_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5469_task-filmreels_orders.csv', 'path': 'orders/sub-5469_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5470_task-filmreels_orders.csv', 'path': 'orders/sub-5470_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5471_task-filmreels_orders.csv', 'path': 'orders/sub-5471_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5472_task-filmreels_orders.csv', 'path': 'orders/sub-5472_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5473_task-filmreels_orders.csv', 'path': 'orders/sub-5473_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5474_task-filmreels_orders.csv', 'path': 'orders/sub-5474_task-filmreels_orders.csv'},
    {'name': 'orders/sub-5475_task-filmreels_orders.csv', 'path': 'orders/sub-5475_task-filmreels_orders.csv'},
    {'name': 'orders/sub-9999_task-filmreels_orders.csv', 'path': 'orders/sub-9999_task-filmreels_orders.csv'},
    {'name': 'stimuli/filmreel_101.png', 'path': 'stimuli/filmreel_101.png'},
    {'name': 'stimuli/filmreel_102.png', 'path': 'stimuli/filmreel_102.png'},
    {'name': 'stimuli/filmreel_103.png', 'path': 'stimuli/filmreel_103.png'},
    {'name': 'stimuli/filmreel_104.png', 'path': 'stimuli/filmreel_104.png'},
    {'name': 'stimuli/filmreel_105.png', 'path': 'stimuli/filmreel_105.png'},
    {'name': 'stimuli/filmreel_106.png', 'path': 'stimuli/filmreel_106.png'},
    {'name': 'stimuli/filmreel_107.png', 'path': 'stimuli/filmreel_107.png'},
    {'name': 'stimuli/filmreel_108.png', 'path': 'stimuli/filmreel_108.png'},
    {'name': 'stimuli/filmreel_201.png', 'path': 'stimuli/filmreel_201.png'},
    {'name': 'stimuli/filmreel_202.png', 'path': 'stimuli/filmreel_202.png'},
    {'name': 'stimuli/filmreel_203.png', 'path': 'stimuli/filmreel_203.png'},
    {'name': 'stimuli/filmreel_204.png', 'path': 'stimuli/filmreel_204.png'},
    {'name': 'stimuli/filmreel_205.png', 'path': 'stimuli/filmreel_205.png'},
    {'name': 'stimuli/filmreel_206.png', 'path': 'stimuli/filmreel_206.png'},
    {'name': 'stimuli/filmreel_207.png', 'path': 'stimuli/filmreel_207.png'},
    {'name': 'stimuli/filmreel_208.png', 'path': 'stimuli/filmreel_208.png'},
    {'name': 'stimuli/filmreel_301.png', 'path': 'stimuli/filmreel_301.png'},
    {'name': 'stimuli/filmreel_302.png', 'path': 'stimuli/filmreel_302.png'},
    {'name': 'stimuli/filmreel_303.png', 'path': 'stimuli/filmreel_303.png'},
    {'name': 'stimuli/filmreel_304.png', 'path': 'stimuli/filmreel_304.png'},
    {'name': 'stimuli/filmreel_305.png', 'path': 'stimuli/filmreel_305.png'},
    {'name': 'stimuli/filmreel_306.png', 'path': 'stimuli/filmreel_306.png'},
    {'name': 'stimuli/filmreel_307.png', 'path': 'stimuli/filmreel_307.png'},
    {'name': 'stimuli/filmreel_308.png', 'path': 'stimuli/filmreel_308.png'},
    {'name': 'stimuli/consent.png', 'path': 'stimuli/consent.png'},
    {'name': 'stimuli/practice/pexels-photo-2082090.jpeg', 'path': 'stimuli/practice/pexels-photo-2082090.jpeg'},
    {'name': 'stimuli/practice/pexels-photo-3705539.jpeg', 'path': 'stimuli/practice/pexels-photo-3705539.jpeg'},
    {'name': 'stimuli/practice/prac_filmreel_A.png', 'path': 'stimuli/practice/prac_filmreel_A.png'},
    {'name': 'stimuli/practice/prac_filmreel_B.png', 'path': 'stimuli/practice/prac_filmreel_B.png'},
    {'name': 'stimuli/pexels-photo-3821674.jpeg', 'path': 'stimuli/pexels-photo-3821674.jpeg'},
    {'name': 'quiz.csv', 'path': 'quiz.csv'},
    {'name': 'images/social/free-photo-of-a-group-of-young-people-at-the-basketball-court-outdoors-in-summer.jpeg', 'path': 'images/social/free-photo-of-a-group-of-young-people-at-the-basketball-court-outdoors-in-summer.jpeg'},
    {'name': 'images/social/free-photo-of-city-road-man-people.jpeg', 'path': 'images/social/free-photo-of-city-road-man-people.jpeg'},
    {'name': 'images/social/free-photo-of-musician-park.jpeg', 'path': 'images/social/free-photo-of-musician-park.jpeg'},
    {'name': 'images/social/free-photo-of-three-women-catering-food-in-a-park.jpeg', 'path': 'images/social/free-photo-of-three-women-catering-food-in-a-park.jpeg'},
    {'name': 'images/social/pexels-photo-196652.jpeg', 'path': 'images/social/pexels-photo-196652.jpeg'},
    {'name': 'images/social/pexels-photo-711009.jpeg', 'path': 'images/social/pexels-photo-711009.jpeg'},
    {'name': 'images/social/pexels-photo-1036804.jpeg', 'path': 'images/social/pexels-photo-1036804.jpeg'},
    {'name': 'images/social/pexels-photo-1076081.jpeg', 'path': 'images/social/pexels-photo-1076081.jpeg'},
    {'name': 'images/social/pexels-photo-1267697.jpeg', 'path': 'images/social/pexels-photo-1267697.jpeg'},
    {'name': 'images/social/pexels-photo-1522344.jpeg', 'path': 'images/social/pexels-photo-1522344.jpeg'},
    {'name': 'images/social/pexels-photo-1546328.jpeg', 'path': 'images/social/pexels-photo-1546328.jpeg'},
    {'name': 'images/social/pexels-photo-1778412.jpeg', 'path': 'images/social/pexels-photo-1778412.jpeg'},
    {'name': 'images/social/pexels-photo-2121661.jpeg', 'path': 'images/social/pexels-photo-2121661.jpeg'},
    {'name': 'images/social/pexels-photo-2608517.jpeg', 'path': 'images/social/pexels-photo-2608517.jpeg'},
    {'name': 'images/social/pexels-photo-2981571.jpeg', 'path': 'images/social/pexels-photo-2981571.jpeg'},
    {'name': 'images/social/pexels-photo-3771824.jpeg', 'path': 'images/social/pexels-photo-3771824.jpeg'},
    {'name': 'images/social/pexels-photo-3777017.jpeg', 'path': 'images/social/pexels-photo-3777017.jpeg'},
    {'name': 'images/social/pexels-photo-3796810.jpeg', 'path': 'images/social/pexels-photo-3796810.jpeg'},
    {'name': 'images/social/pexels-photo-3894383.jpeg', 'path': 'images/social/pexels-photo-3894383.jpeg'},
    {'name': 'images/social/pexels-photo-4173325.jpeg', 'path': 'images/social/pexels-photo-4173325.jpeg'},
    {'name': 'images/social/pexels-photo-4279124.jpeg', 'path': 'images/social/pexels-photo-4279124.jpeg'},
    {'name': 'images/social/pexels-photo-4669907.jpeg', 'path': 'images/social/pexels-photo-4669907.jpeg'},
    {'name': 'images/social/pexels-photo-4686816.jpeg', 'path': 'images/social/pexels-photo-4686816.jpeg'},
    {'name': 'images/social/pexels-photo-4833957.jpeg', 'path': 'images/social/pexels-photo-4833957.jpeg'},
    {'name': 'images/social/pexels-photo-5055264.jpeg', 'path': 'images/social/pexels-photo-5055264.jpeg'},
    {'name': 'images/social/pexels-photo-5197810.jpeg', 'path': 'images/social/pexels-photo-5197810.jpeg'},
    {'name': 'images/social/pexels-photo-5418924.jpeg', 'path': 'images/social/pexels-photo-5418924.jpeg'},
    {'name': 'images/social/pexels-photo-5676744.jpeg', 'path': 'images/social/pexels-photo-5676744.jpeg'},
    {'name': 'images/social/pexels-photo-5757068.jpeg', 'path': 'images/social/pexels-photo-5757068.jpeg'},
    {'name': 'images/social/pexels-photo-5791658.jpeg', 'path': 'images/social/pexels-photo-5791658.jpeg'},
    {'name': 'images/social/pexels-photo-5805087.jpeg', 'path': 'images/social/pexels-photo-5805087.jpeg'},
    {'name': 'images/social/pexels-photo-5807585.jpeg', 'path': 'images/social/pexels-photo-5807585.jpeg'},
    {'name': 'images/social/pexels-photo-5836947.jpeg', 'path': 'images/social/pexels-photo-5836947.jpeg'},
    {'name': 'images/social/pexels-photo-5920663.jpeg', 'path': 'images/social/pexels-photo-5920663.jpeg'},
    {'name': 'images/social/pexels-photo-5935189.jpeg', 'path': 'images/social/pexels-photo-5935189.jpeg'},
    {'name': 'images/social/pexels-photo-5936039.jpeg', 'path': 'images/social/pexels-photo-5936039.jpeg'},
    {'name': 'images/social/pexels-photo-6050435.jpeg', 'path': 'images/social/pexels-photo-6050435.jpeg'},
    {'name': 'images/social/pexels-photo-6063426.jpeg', 'path': 'images/social/pexels-photo-6063426.jpeg'},
    {'name': 'images/social/pexels-photo-6114997.jpeg', 'path': 'images/social/pexels-photo-6114997.jpeg'},
    {'name': 'images/social/pexels-photo-6146931.jpeg', 'path': 'images/social/pexels-photo-6146931.jpeg'},
    {'name': 'images/social/pexels-photo-6174062.jpeg', 'path': 'images/social/pexels-photo-6174062.jpeg'},
    {'name': 'images/social/pexels-photo-6180398.jpeg', 'path': 'images/social/pexels-photo-6180398.jpeg'},
    {'name': 'images/social/pexels-photo-6205538.jpeg', 'path': 'images/social/pexels-photo-6205538.jpeg'},
    {'name': 'images/social/pexels-photo-6457515.jpeg', 'path': 'images/social/pexels-photo-6457515.jpeg'},
    {'name': 'images/social/pexels-photo-6463600.jpeg', 'path': 'images/social/pexels-photo-6463600.jpeg'},
    {'name': 'images/social/pexels-photo-6827325.jpeg', 'path': 'images/social/pexels-photo-6827325.jpeg'},
    {'name': 'images/social/pexels-photo-6896221.jpeg', 'path': 'images/social/pexels-photo-6896221.jpeg'},
    {'name': 'images/social/pexels-photo-6954063.jpeg', 'path': 'images/social/pexels-photo-6954063.jpeg'},
    {'name': 'images/social/pexels-photo-6963327.jpeg', 'path': 'images/social/pexels-photo-6963327.jpeg'},
    {'name': 'images/social/pexels-photo-7429514.jpeg', 'path': 'images/social/pexels-photo-7429514.jpeg'},
    {'name': 'images/social/pexels-photo-7502601.jpeg', 'path': 'images/social/pexels-photo-7502601.jpeg'},
    {'name': 'images/social/pexels-photo-7510721.jpeg', 'path': 'images/social/pexels-photo-7510721.jpeg'},
    {'name': 'images/social/pexels-photo-7551755.jpeg', 'path': 'images/social/pexels-photo-7551755.jpeg'},
    {'name': 'images/social/pexels-photo-7646192.jpeg', 'path': 'images/social/pexels-photo-7646192.jpeg'},
    {'name': 'images/social/pexels-photo-7886787.jpeg', 'path': 'images/social/pexels-photo-7886787.jpeg'},
    {'name': 'images/social/pexels-photo-8111367.jpeg', 'path': 'images/social/pexels-photo-8111367.jpeg'},
    {'name': 'images/social/pexels-photo-8415167.jpeg', 'path': 'images/social/pexels-photo-8415167.jpeg'},
    {'name': 'images/social/pexels-photo-8761649.jpeg', 'path': 'images/social/pexels-photo-8761649.jpeg'},
    {'name': 'images/social/pexels-photo-8815330.jpeg', 'path': 'images/social/pexels-photo-8815330.jpeg'},
    {'name': 'images/social/pexels-photo-9068971.jpeg', 'path': 'images/social/pexels-photo-9068971.jpeg'},
    {'name': 'images/social/pexels-photo-9807580.jpeg', 'path': 'images/social/pexels-photo-9807580.jpeg'},
    {'name': 'images/social/pexels-photo-9961871.jpeg', 'path': 'images/social/pexels-photo-9961871.jpeg'},
    {'name': 'images/social/pexels-photo-12169159.jpeg', 'path': 'images/social/pexels-photo-12169159.jpeg'},
    {'name': 'images/social/pexels-photo-13096563.jpeg', 'path': 'images/social/pexels-photo-13096563.jpeg'},
    {'name': 'images/nature/free-photo-of-aerial-view-of-mountain-landscape.jpeg', 'path': 'images/nature/free-photo-of-aerial-view-of-mountain-landscape.jpeg'},
    {'name': 'images/nature/free-photo-of-a-marsh-in-a-valley.jpeg', 'path': 'images/nature/free-photo-of-a-marsh-in-a-valley.jpeg'},
    {'name': 'images/nature/free-photo-of-autumnal-trees-around-a-pond-in-a-park.jpeg', 'path': 'images/nature/free-photo-of-autumnal-trees-around-a-pond-in-a-park.jpeg'},
    {'name': 'images/nature/free-photo-of-autumn-forest-by-lake.jpeg', 'path': 'images/nature/free-photo-of-autumn-forest-by-lake.jpeg'},
    {'name': 'images/nature/free-photo-of-clouds-over-hill.jpeg', 'path': 'images/nature/free-photo-of-clouds-over-hill.jpeg'},
    {'name': 'images/nature/free-photo-of-forest-with-mountains-in-snow-behind.jpeg', 'path': 'images/nature/free-photo-of-forest-with-mountains-in-snow-behind.jpeg'},
    {'name': 'images/nature/free-photo-of-landscape-of-a-grass-field-and-trees-in-summer.jpeg', 'path': 'images/nature/free-photo-of-landscape-of-a-grass-field-and-trees-in-summer.jpeg'},
    {'name': 'images/nature/free-photo-of-landscape-of-a-poppy-field-and-mountains-in-the-background.jpeg', 'path': 'images/nature/free-photo-of-landscape-of-a-poppy-field-and-mountains-in-the-background.jpeg'},
    {'name': 'images/nature/free-photo-of-landscape-of-coniferous-trees-river-and-mountains.jpeg', 'path': 'images/nature/free-photo-of-landscape-of-coniferous-trees-river-and-mountains.jpeg'},
    {'name': 'images/nature/free-photo-of-landscape-of-rocky-snowcapped-mountain-peaks.jpeg', 'path': 'images/nature/free-photo-of-landscape-of-rocky-snowcapped-mountain-peaks.jpeg'},
    {'name': 'images/nature/free-photo-of-low-angle-shot-of-snow-covered-mountains.jpeg', 'path': 'images/nature/free-photo-of-low-angle-shot-of-snow-covered-mountains.jpeg'},
    {'name': 'images/nature/free-photo-of-seascape-with-setting-sun-orange-sky-and-purple-clouds.jpeg', 'path': 'images/nature/free-photo-of-seascape-with-setting-sun-orange-sky-and-purple-clouds.jpeg'},
    {'name': 'images/nature/free-photo-of-sunlit-forest-in-mountains.jpeg', 'path': 'images/nature/free-photo-of-sunlit-forest-in-mountains.jpeg'},
    {'name': 'images/nature/jackson-lake-grand-teton-national-park-wyoming-water-69384.jpeg', 'path': 'images/nature/jackson-lake-grand-teton-national-park-wyoming-water-69384.jpeg'},
    {'name': 'images/nature/monument-valley-utah-usa-red-86428.jpeg', 'path': 'images/nature/monument-valley-utah-usa-red-86428.jpeg'},
    {'name': 'images/nature/pexels-photo-189848.jpeg', 'path': 'images/nature/pexels-photo-189848.jpeg'},
    {'name': 'images/nature/pexels-photo-210349.jpeg', 'path': 'images/nature/pexels-photo-210349.jpeg'},
    {'name': 'images/nature/pexels-photo-218673.jpeg', 'path': 'images/nature/pexels-photo-218673.jpeg'},
    {'name': 'images/nature/pexels-photo-219890.jpeg', 'path': 'images/nature/pexels-photo-219890.jpeg'},
    {'name': 'images/nature/pexels-photo-237321.jpeg', 'path': 'images/nature/pexels-photo-237321.jpeg'},
    {'name': 'images/nature/pexels-photo-248195.jpeg', 'path': 'images/nature/pexels-photo-248195.jpeg'},
    {'name': 'images/nature/pexels-photo-259881.jpeg', 'path': 'images/nature/pexels-photo-259881.jpeg'},
    {'name': 'images/nature/pexels-photo-267104.jpeg', 'path': 'images/nature/pexels-photo-267104.jpeg'},
    {'name': 'images/nature/pexels-photo-301375.jpeg', 'path': 'images/nature/pexels-photo-301375.jpeg'},
    {'name': 'images/nature/pexels-photo-301395.jpeg', 'path': 'images/nature/pexels-photo-301395.jpeg'},
    {'name': 'images/nature/pexels-photo-326058.jpeg', 'path': 'images/nature/pexels-photo-326058.jpeg'},
    {'name': 'images/nature/pexels-photo-373447.jpeg', 'path': 'images/nature/pexels-photo-373447.jpeg'},
    {'name': 'images/nature/pexels-photo-414083.jpeg', 'path': 'images/nature/pexels-photo-414083.jpeg'},
    {'name': 'images/nature/pexels-photo-414122.jpeg', 'path': 'images/nature/pexels-photo-414122.jpeg'},
    {'name': 'images/nature/pexels-photo-589841.jpeg', 'path': 'images/nature/pexels-photo-589841.jpeg'},
    {'name': 'images/nature/pexels-photo-629161.jpeg', 'path': 'images/nature/pexels-photo-629161.jpeg'},
    {'name': 'images/nature/pexels-photo-640805.jpeg', 'path': 'images/nature/pexels-photo-640805.jpeg'},
    {'name': 'images/nature/pexels-photo-672451.jpeg', 'path': 'images/nature/pexels-photo-672451.jpeg'},
    {'name': 'images/nature/pexels-photo-673020.jpeg', 'path': 'images/nature/pexels-photo-673020.jpeg'},
    {'name': 'images/nature/pexels-photo-709552.jpeg', 'path': 'images/nature/pexels-photo-709552.jpeg'},
    {'name': 'images/nature/pexels-photo-959912.jpeg', 'path': 'images/nature/pexels-photo-959912.jpeg'},
    {'name': 'images/nature/pexels-photo-975771.jpeg', 'path': 'images/nature/pexels-photo-975771.jpeg'},
    {'name': 'images/nature/pexels-photo-1021808.jpeg', 'path': 'images/nature/pexels-photo-1021808.jpeg'},
    {'name': 'images/nature/pexels-photo-1045113.jpeg', 'path': 'images/nature/pexels-photo-1045113.jpeg'},
    {'name': 'images/nature/pexels-photo-1062175.jpeg', 'path': 'images/nature/pexels-photo-1062175.jpeg'},
    {'name': 'images/nature/pexels-photo-1126382.jpeg', 'path': 'images/nature/pexels-photo-1126382.jpeg'},
    {'name': 'images/nature/pexels-photo-1462011.jpeg', 'path': 'images/nature/pexels-photo-1462011.jpeg'},
    {'name': 'images/nature/pexels-photo-1480799.jpeg', 'path': 'images/nature/pexels-photo-1480799.jpeg'},
    {'name': 'images/nature/pexels-photo-1576667.jpeg', 'path': 'images/nature/pexels-photo-1576667.jpeg'},
    {'name': 'images/nature/pexels-photo-1659689.jpeg', 'path': 'images/nature/pexels-photo-1659689.jpeg'},
    {'name': 'images/nature/pexels-photo-1679551.jpeg', 'path': 'images/nature/pexels-photo-1679551.jpeg'},
    {'name': 'images/nature/pexels-photo-1684166.jpeg', 'path': 'images/nature/pexels-photo-1684166.jpeg'},
    {'name': 'images/nature/pexels-photo-1690355.jpeg', 'path': 'images/nature/pexels-photo-1690355.jpeg'},
    {'name': 'images/nature/pexels-photo-2067659.jpeg', 'path': 'images/nature/pexels-photo-2067659.jpeg'},
    {'name': 'images/nature/pexels-photo-2314983.jpeg', 'path': 'images/nature/pexels-photo-2314983.jpeg'},
    {'name': 'images/nature/pexels-photo-2387661.jpeg', 'path': 'images/nature/pexels-photo-2387661.jpeg'},
    {'name': 'images/nature/pexels-photo-2539453.jpeg', 'path': 'images/nature/pexels-photo-2539453.jpeg'},
    {'name': 'images/nature/pexels-photo-2548535.jpeg', 'path': 'images/nature/pexels-photo-2548535.jpeg'},
    {'name': 'images/nature/pexels-photo-2645414.jpeg', 'path': 'images/nature/pexels-photo-2645414.jpeg'},
    {'name': 'images/nature/pexels-photo-2835436.jpeg', 'path': 'images/nature/pexels-photo-2835436.jpeg'},
    {'name': 'images/nature/pexels-photo-2871478.jpeg', 'path': 'images/nature/pexels-photo-2871478.jpeg'},
    {'name': 'images/nature/pexels-photo-2878019.jpeg', 'path': 'images/nature/pexels-photo-2878019.jpeg'},
    {'name': 'images/nature/pexels-photo-2888333.jpeg', 'path': 'images/nature/pexels-photo-2888333.jpeg'},
    {'name': 'images/nature/pexels-photo-3948134.jpeg', 'path': 'images/nature/pexels-photo-3948134.jpeg'},
    {'name': 'images/nature/pexels-photo-4450074.jpeg', 'path': 'images/nature/pexels-photo-4450074.jpeg'},
    {'name': 'images/nature/pexels-photo-6610368.jpeg', 'path': 'images/nature/pexels-photo-6610368.jpeg'},
    {'name': 'images/nature/pexels-photo-9031183.jpeg', 'path': 'images/nature/pexels-photo-9031183.jpeg'},
    {'name': 'images/nature/poppy-field-of-poppies-flower-flowers-80453.jpeg', 'path': 'images/nature/poppy-field-of-poppies-flower-flowers-80453.jpeg'},
    {'name': 'images/nature/turret-arch-snow-winter-sandstone-99570.jpeg', 'path': 'images/nature/turret-arch-snow-winter-sandstone-99570.jpeg'},
    {'name': 'images/food/free-photo-of-delicious-pasta-with-roasted-meat.jpeg', 'path': 'images/food/free-photo-of-delicious-pasta-with-roasted-meat.jpeg'},
    {'name': 'images/food/free-photo-of-toasted-sandwiches-and-dip.jpeg', 'path': 'images/food/free-photo-of-toasted-sandwiches-and-dip.jpeg'},
    {'name': 'images/food/pexels-photo-139746.jpeg', 'path': 'images/food/pexels-photo-139746.jpeg'},
    {'name': 'images/food/pexels-photo-221063.jpeg', 'path': 'images/food/pexels-photo-221063.jpeg'},
    {'name': 'images/food/pexels-photo-262959.jpeg', 'path': 'images/food/pexels-photo-262959.jpeg'},
    {'name': 'images/food/pexels-photo-264727.jpeg', 'path': 'images/food/pexels-photo-264727.jpeg'},
    {'name': 'images/food/pexels-photo-302468.jpeg', 'path': 'images/food/pexels-photo-302468.jpeg'},
    {'name': 'images/food/pexels-photo-376464.jpeg', 'path': 'images/food/pexels-photo-376464.jpeg'},
    {'name': 'images/food/pexels-photo-461431.jpeg', 'path': 'images/food/pexels-photo-461431.jpeg'},
    {'name': 'images/food/pexels-photo-792406.jpeg', 'path': 'images/food/pexels-photo-792406.jpeg'},
    {'name': 'images/food/pexels-photo-793785.jpeg', 'path': 'images/food/pexels-photo-793785.jpeg'},
    {'name': 'images/food/pexels-photo-806357.jpeg', 'path': 'images/food/pexels-photo-806357.jpeg'},
    {'name': 'images/food/pexels-photo-827513.jpeg', 'path': 'images/food/pexels-photo-827513.jpeg'},
    {'name': 'images/food/pexels-photo-842142.jpeg', 'path': 'images/food/pexels-photo-842142.jpeg'},
    {'name': 'images/food/pexels-photo-1001773.jpeg', 'path': 'images/food/pexels-photo-1001773.jpeg'},
    {'name': 'images/food/pexels-photo-1146760.jpeg', 'path': 'images/food/pexels-photo-1146760.jpeg'},
    {'name': 'images/food/pexels-photo-1228530.jpeg', 'path': 'images/food/pexels-photo-1228530.jpeg'},
    {'name': 'images/food/pexels-photo-1309595.jpeg', 'path': 'images/food/pexels-photo-1309595.jpeg'},
    {'name': 'images/food/pexels-photo-1437267.jpeg', 'path': 'images/food/pexels-photo-1437267.jpeg'},
    {'name': 'images/food/pexels-photo-1707917.jpeg', 'path': 'images/food/pexels-photo-1707917.jpeg'},
    {'name': 'images/food/pexels-photo-1833336.jpeg', 'path': 'images/food/pexels-photo-1833336.jpeg'},
    {'name': 'images/food/pexels-photo-1860208.jpeg', 'path': 'images/food/pexels-photo-1860208.jpeg'},
    {'name': 'images/food/pexels-photo-2059151.jpeg', 'path': 'images/food/pexels-photo-2059151.jpeg'},
    {'name': 'images/food/pexels-photo-2087748.jpeg', 'path': 'images/food/pexels-photo-2087748.jpeg'},
    {'name': 'images/food/pexels-photo-2092897.jpeg', 'path': 'images/food/pexels-photo-2092897.jpeg'},
    {'name': 'images/food/pexels-photo-2144112.jpeg', 'path': 'images/food/pexels-photo-2144112.jpeg'},
    {'name': 'images/food/pexels-photo-2347311.jpeg', 'path': 'images/food/pexels-photo-2347311.jpeg'},
    {'name': 'images/food/pexels-photo-2412950.jpeg', 'path': 'images/food/pexels-photo-2412950.jpeg'},
    {'name': 'images/food/pexels-photo-2532006.jpeg', 'path': 'images/food/pexels-photo-2532006.jpeg'},
    {'name': 'images/food/pexels-photo-2725744.jpeg', 'path': 'images/food/pexels-photo-2725744.jpeg'},
    {'name': 'images/food/pexels-photo-3026808.jpeg', 'path': 'images/food/pexels-photo-3026808.jpeg'},
    {'name': 'images/food/pexels-photo-3209101.jpeg', 'path': 'images/food/pexels-photo-3209101.jpeg'},
    {'name': 'images/food/pexels-photo-3386854.jpeg', 'path': 'images/food/pexels-photo-3386854.jpeg'},
    {'name': 'images/food/pexels-photo-4001870.jpeg', 'path': 'images/food/pexels-photo-4001870.jpeg'},
    {'name': 'images/food/pexels-photo-4061475.jpeg', 'path': 'images/food/pexels-photo-4061475.jpeg'},
    {'name': 'images/food/pexels-photo-4101805.jpeg', 'path': 'images/food/pexels-photo-4101805.jpeg'},
    {'name': 'images/food/pexels-photo-4109532.jpeg', 'path': 'images/food/pexels-photo-4109532.jpeg'},
    {'name': 'images/food/pexels-photo-4181933.jpeg', 'path': 'images/food/pexels-photo-4181933.jpeg'},
    {'name': 'images/food/pexels-photo-4913349.jpeg', 'path': 'images/food/pexels-photo-4913349.jpeg'},
    {'name': 'images/food/pexels-photo-4955210.jpeg', 'path': 'images/food/pexels-photo-4955210.jpeg'},
    {'name': 'images/food/pexels-photo-4958641.jpeg', 'path': 'images/food/pexels-photo-4958641.jpeg'},
    {'name': 'images/food/pexels-photo-5507640.jpeg', 'path': 'images/food/pexels-photo-5507640.jpeg'},
    {'name': 'images/food/pexels-photo-5773996.jpeg', 'path': 'images/food/pexels-photo-5773996.jpeg'},
    {'name': 'images/food/pexels-photo-7462777.jpeg', 'path': 'images/food/pexels-photo-7462777.jpeg'},
    {'name': 'images/food/pexels-photo-7474117.jpeg', 'path': 'images/food/pexels-photo-7474117.jpeg'},
    {'name': 'images/food/pexels-photo-7627443.jpeg', 'path': 'images/food/pexels-photo-7627443.jpeg'},
    {'name': 'images/food/pexels-photo-8746403.jpeg', 'path': 'images/food/pexels-photo-8746403.jpeg'},
    {'name': 'images/food/pexels-photo-8963961.jpeg', 'path': 'images/food/pexels-photo-8963961.jpeg'},
    {'name': 'images/food/pexels-photo-9213884.jpeg', 'path': 'images/food/pexels-photo-9213884.jpeg'},
    {'name': 'images/food/pexels-photo-9525081.jpeg', 'path': 'images/food/pexels-photo-9525081.jpeg'},
    {'name': 'images/food/pexels-photo-9609862.jpeg', 'path': 'images/food/pexels-photo-9609862.jpeg'},
    {'name': 'images/food/pexels-photo-9650087.jpeg', 'path': 'images/food/pexels-photo-9650087.jpeg'},
    {'name': 'images/food/pexels-photo-9928198.jpeg', 'path': 'images/food/pexels-photo-9928198.jpeg'},
    {'name': 'images/food/pexels-photo-10043311.jpeg', 'path': 'images/food/pexels-photo-10043311.jpeg'},
    {'name': 'images/food/pexels-photo-10480248.jpeg', 'path': 'images/food/pexels-photo-10480248.jpeg'},
    {'name': 'images/food/pexels-photo-10790638.jpeg', 'path': 'images/food/pexels-photo-10790638.jpeg'},
    {'name': 'images/food/pexels-photo-12027631.jpeg', 'path': 'images/food/pexels-photo-12027631.jpeg'},
    {'name': 'images/food/pexels-photo-12905676.jpeg', 'path': 'images/food/pexels-photo-12905676.jpeg'},
    {'name': 'images/food/pexels-photo-12955612.jpeg', 'path': 'images/food/pexels-photo-12955612.jpeg'},
    {'name': 'images/food/pexels-photo-12973148.jpeg', 'path': 'images/food/pexels-photo-12973148.jpeg'},
    {'name': 'images/food/pexels-photo-12984979.jpeg', 'path': 'images/food/pexels-photo-12984979.jpeg'},
    {'name': 'images/food/pexels-photo-13689827.jpeg', 'path': 'images/food/pexels-photo-13689827.jpeg'},
    {'name': 'images/food/pexels-photo-14537699.jpeg', 'path': 'images/food/pexels-photo-14537699.jpeg'},
    {'name': 'images/food/pexels-photo-16000781.jpeg', 'path': 'images/food/pexels-photo-16000781.jpeg'},
    {'name': 'stimuli/blank.jpg', 'path': 'stimuli/blank.jpg'},
    {'name': 'stimuli/frame.png', 'path': 'stimuli/frame.png'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2023.2.3';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://redcap.mountsinai.org/redcap/surveys/?s=PKFDMEK9FFM3HYXL', '');


  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/sub-${expInfo["prolific_id"]}_task-filmreels_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var exp_startClock;
var socialPts;
var foodPts;
var naturePts;
var cumulPts;
var lastCravingRating;
var thisExp;
var orderID;
var consentClock;
var consent_text;
var continue_to_study;
var agree_consent;
var instructionsClock;
var instr_keyboard;
var left_img_instr;
var right_img_instr;
var photo_obj_instr;
var blank_obj_instr;
var frame_obj_instr;
var prac_startClock;
var prac_start_txt;
var begin_prac;
var prac_get_trial_infoClock;
var prac_choiceClock;
var left_img_2;
var right_img_2;
var prac_choice_instr;
var prac_resp;
var prac_choice_feedbackClock;
var square_3;
var left_img_fb_2;
var right_img_fb_2;
var isiClock;
var fix_rand;
var prac_outcomeClock;
var photo_obj_2;
var frame_obj_2;
var prac_cravingClock;
var socialCIC_slider_prac;
var social_contact_txt_2;
var ins_craving_rate_txt_2;
var craving_kb_2;
var prac_trial_fb_txtClock;
var prac_trial_end_txt;
var prac_continue_2;
var quizInstrClock;
var quiz_instr;
var quiz_continue;
var quiz_quesClock;
var quiz_q;
var quizKeyboard;
var true_or_false_txt;
var quiz_feedbackClock;
var CORRECT_OR_INCORRECT;
var quiz_feedback_text;
var quizAdvance;
var get_readyClock;
var waiting;
var key_advance;
var get_trial_infoClock;
var cravingClock;
var socialCIC_slider;
var social_contact_txt;
var ins_craving_rate_txt;
var craving_kb;
var choiceClock;
var left_img;
var right_img;
var key_resp;
var choice_feedbackClock;
var square;
var left_img_fb;
var right_img_fb;
var outcomeClock;
var photo_obj;
var frame_obj;
var isi_breakClock;
var fix_2;
var rating_txt;
var key_resp_2;
var img_ratingClock;
var rating_display;
var rating_resp;
var left_img_rate;
var right_img_rate;
var take_breakClock;
var break_txt_obj;
var stop_break;
var exp_endClock;
var key_resp_6;
var text_4;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "exp_start"
  exp_startClock = new util.Clock();
  // Run 'Begin Experiment' code from startup_code
  socialPts = 0;
  foodPts = 0;
  naturePts = 0;
  cumulPts = 0;
  lastCravingRating = 5;
  
  thisExp=psychoJS.experiment;
  // Run 'Begin Experiment' code from hide_mouse
  document.body.style.cursor='none';
  // Run 'Begin Experiment' code from get_subj_count
  orderID = await psychoJS.shelf.getIntegerValue({key: ['orderID'], defaultValue: 0})
  psychoJS.shelf.addIntegerValue({key: ['orderID'], delta: 1})
  psychoJS.experiment.addData("order_id", orderID);
  
  //util.addInfoFromUrl(participantN);
  // Initialize components for Routine "consent"
  consentClock = new util.Clock();
  consent_text = new visual.TextBox({
    win: psychoJS.window,
    name: 'consent_text',
    text: 'ICAHN SCHOOL OF MEDICINE AT MOUNT SINAI\nRESEARCH INFORMATION SHEET\nStudy ID: IRB-18-01301 \nForm Version Date: 30 Jan 2023\nStudy Title: Computational Mechanisms of Decision Making\nPrincipal Investigator (Lead Researcher): Xiaosi Gu, Ph.D.\nAddress: 55 W 125th Street, 13th Floor, New York, NY 10027\nPhone: 212-824-9531\n\nThe purpose of this research study is to help us better understand how people make decisions and what aspects of ourselves affect our decision-making processes. You are being asked to take part in a research study because you are at least 18 years of age and are fluent in English. You must be at least 18 years old to participate. If you are younger than 18 years old, please stop now.\n\nParticipation in the research study is voluntary. You can agree to join or not. You can also say yes now, and change your mind later. Deciding not to be in the research study, now or later, will not affect your ability to receive medical care at Mount Sinai.\n\nYour participation in this research study is expected to last 60 minutes. If you choose to participate, you will be asked to complete two sections of the study. In part one, we will ask you to play a game in which you will be presented with some information and asked to make decisions based on the information you have. We will give you more specific instructions for the game before you begin and there will also be a chance to practice.\n\nIn part two, you will be asked to answer standard demographic questions as well as a series of surveys. Please read through these carefully and answer thoughtfully. The questions we ask should be straightforward and clear, but if you are unsure of what is being asked, make your best guess, and please let us know at the end of your participation. You can choose not to answer any question you do not wish to answer. You can also choose to stop taking the survey at any time.\n\nThe possible risks to you in taking part in this research are:\n● You may find the group of surveys and tasks somewhat tedious, boring, or intrusive. To aid the former, brief breaks will be given during assessment. To address the latter concern, we would like to reiterate that you can end your participation at any time.\n● Any time information is collected, there is a potential risk for loss of confidentiality. Your information will be handled as confidentially as possible. Confidentiality of your participation and the information you convey is a priority for research staff and also is presumed and must be maintained unless the investigator obtains the express permission from you to do otherwise. Every effort will be made to keep your information confidential.\n\nTo protect your identity as a research subject, no identifiable information will be collected. If you have any questions about this research, please contact the Lead Researcher at 212-824-9531. You can also call the Program for the Protection of Human Subjects Office at (212) 824-8200. This project was determined to be exempt from federal human subjects research regulations. Rev. 11.11.2022',
    placeholder: 'Type here...',
    font: 'Arial',
    pos: [0, 0], 
    letterHeight: 0.02,
    lineSpacing: 1.0,
    size: [1.25, 0.75],  units: undefined, 
    color: 'black', colorSpace: 'rgb',
    fillColor: undefined, borderColor: undefined,
    languageStyle: 'LTR',
    bold: false, italic: false,
    opacity: undefined,
    padding: 0.0,
    alignment: 'center-left',
    overflow: 'visible',
    editable: false,
    multiline: true,
    anchor: 'center',
    depth: 0.0 
  });
  
  continue_to_study = new visual.TextStim({
    win: psychoJS.window,
    name: 'continue_to_study',
    text: 'Press SPACE to continue to study',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  agree_consent = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  instr_keyboard = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Run 'Begin Experiment' code from draw_instr_objs
  left_img_instr = new visual.ImageStim({"win": psychoJS.window, "name": "left_img_instr", "image": "stimuli/practice/prac_filmreel_B.png", "mask": null, "anchor": "center", "ori": 0.0, "pos": [(- 0.25), (- 0.175)], "size": [0.33, 0.33], "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 3.0)});
  right_img_instr = new visual.ImageStim({"win": psychoJS.window, "name": "right_img_instr", "image": "stimuli/practice/prac_filmreel_A.png", "mask": null, "anchor": "center", "ori": 0.0, "pos": [0.25, (- 0.175)], "size": [0.33, 0.33], "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 4.0)});
  photo_obj_instr = new visual.ImageStim({"win": psychoJS.window, "name": "photo_obj_instr", "units": "height", "image": "stimuli/pexels-photo-3821674.jpeg", "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, (- 0.175)], "size": [0.3, 0.2], "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 5.0)});
  blank_obj_instr = new visual.ImageStim({"win": psychoJS.window, "name": "blank_obj_instr", "units": "height", "image": "stimuli/blank.jpg", "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, (- 0.175)], "size": [0.3, 0.2], "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 6.0)});
  frame_obj_instr = new visual.ImageStim({"win": psychoJS.window, "name": "frame_obj_instr", "units": "height", "image": "stimuli/frame.png", "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, (- 0.175)], "size": [0.3, 0.28], "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 7.0)});
  left_img_instr.autoDraw = false;
  right_img_instr.autoDraw = false;
  photo_obj_instr.autoDraw = false;
  blank_obj_instr.autoDraw = false;
  frame_obj_instr.autoDraw = false;
  
  // Initialize components for Routine "prac_start"
  prac_startClock = new util.Clock();
  prac_start_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_start_txt',
    text: "Before you begin the game, let's look at some examples.\n\nOn the next screen, you will see two different options. You can choose one of them by pressing the arrows on your keyboard. Press the LEFT ARROW to choose the option on the left side of the screen or press the RIGHT ARROW to choose the option on the right side of the screen.",
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  begin_prac = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "prac_get_trial_info"
  prac_get_trial_infoClock = new util.Clock();
  // Initialize components for Routine "prac_choice"
  prac_choiceClock = new util.Clock();
  left_img_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'left_img_2', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [(- 0.25), 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  right_img_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'right_img_2', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0.25, 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  prac_choice_instr = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_choice_instr',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.33], height: 0.035,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  prac_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "prac_choice_feedback"
  prac_choice_feedbackClock = new util.Clock();
  square_3 = new visual.Rect ({
    win: psychoJS.window, name: 'square_3', 
    width: [0.275, 0.275][0], height: [0.275, 0.275][1],
    ori: 0.0, pos: [0, 0],
    anchor: 'center',
    lineWidth: 1.0, 
    colorSpace: 'rgb',
    lineColor: new util.Color('gold'),
    fillColor: new util.Color('gold'),
    opacity: 1.0, depth: -1, interpolate: true,
  });
  
  left_img_fb_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'left_img_fb_2', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [(- 0.25), 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  right_img_fb_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'right_img_fb_2', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0.25, 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  // Initialize components for Routine "isi"
  isiClock = new util.Clock();
  fix_rand = new visual.TextStim({
    win: psychoJS.window,
    name: 'fix_rand',
    text: '+',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "prac_outcome"
  prac_outcomeClock = new util.Clock();
  photo_obj_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'photo_obj_2', units : 'height', 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [0.6, 0.4],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  frame_obj_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'frame_obj_2', units : 'height', 
    image : 'stimuli/frame.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [0.6, 0.56],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  // Initialize components for Routine "prac_craving"
  prac_cravingClock = new util.Clock();
  socialCIC_slider_prac = new visual.Slider({
    win: psychoJS.window, name: 'socialCIC_slider_prac',
    startValue: undefined,
    size: [1.0, 0.1], pos: [0, (- 0.1)], ori: 0.0, units: psychoJS.window.units,
    labels: ["0\nNot At All", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10\nVery Much"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    granularity: 0.25, style: ["RATING"],
    color: new util.Color('black'), markerColor: new util.Color('crimson'), lineColor: new util.Color('black'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: 0, 
    flip: false,
  });
  
  social_contact_txt_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'social_contact_txt_2',
    text: 'How much do you want social contact right now?',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  ins_craving_rate_txt_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ins_craving_rate_txt_2',
    text: 'Use your MOUSE to move the slider\nPress SPACE to submit',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  craving_kb_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "prac_trial_fb_txt"
  prac_trial_fb_txtClock = new util.Clock();
  prac_trial_end_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'prac_trial_end_txt',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  prac_continue_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "quizInstr"
  quizInstrClock = new util.Clock();
  quiz_instr = new visual.TextStim({
    win: psychoJS.window,
    name: 'quiz_instr',
    text: 'Please answer the next 5 TRUE/FALSE questions with your keyboard.\n\nPress "t" if the statement is TRUE \nPress "f" if the statement is FALSE',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  quiz_continue = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "quiz_ques"
  quiz_quesClock = new util.Clock();
  quiz_q = new visual.TextStim({
    win: psychoJS.window,
    name: 'quiz_q',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  quizKeyboard = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  true_or_false_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'true_or_false_txt',
    text: 'Press "t" for TRUE\nPress "f" for FALSE',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.25)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "quiz_feedback"
  quiz_feedbackClock = new util.Clock();
  CORRECT_OR_INCORRECT = new visual.TextStim({
    win: psychoJS.window,
    name: 'CORRECT_OR_INCORRECT',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.25], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  quiz_feedback_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'quiz_feedback_text',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.1)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  quizAdvance = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "get_ready"
  get_readyClock = new util.Clock();
  waiting = new visual.TextStim({
    win: psychoJS.window,
    name: 'waiting',
    text: 'You will complete 12 rounds of this task. Please complete each round without any interruptions. You can take a short break in between each round. You will also be asked to indicate your favorite and least favorite options after each round.\n\nPlease place your fingers on the arrow keys when you are ready and press any key to begin...',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_advance = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "get_trial_info"
  get_trial_infoClock = new util.Clock();
  // Initialize components for Routine "craving"
  cravingClock = new util.Clock();
  socialCIC_slider = new visual.Slider({
    win: psychoJS.window, name: 'socialCIC_slider',
    startValue: undefined,
    size: [1.0, 0.1], pos: [0, (- 0.1)], ori: 0.0, units: psychoJS.window.units,
    labels: ["0\nNot At All", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10\nVery Much"], fontSize: 0.02, ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    granularity: 0.25, style: ["RATING"],
    color: new util.Color('black'), markerColor: new util.Color('crimson'), lineColor: new util.Color('black'), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: 0, 
    flip: false,
  });
  
  social_contact_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'social_contact_txt',
    text: 'How much do you want social contact right now?',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  ins_craving_rate_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'ins_craving_rate_txt',
    text: 'Use your MOUSE to move the slider\nPress SPACE to submit',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  craving_kb = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "choice"
  choiceClock = new util.Clock();
  left_img = new visual.ImageStim({
    win : psychoJS.window,
    name : 'left_img', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [(- 0.25), 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  right_img = new visual.ImageStim({
    win : psychoJS.window,
    name : 'right_img', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0.25, 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "choice_feedback"
  choice_feedbackClock = new util.Clock();
  square = new visual.Rect ({
    win: psychoJS.window, name: 'square', 
    width: [0.275, 0.275][0], height: [0.275, 0.275][1],
    ori: 0.0, pos: [0, 0],
    anchor: 'center',
    lineWidth: 1.0, 
    colorSpace: 'rgb',
    lineColor: new util.Color('gold'),
    fillColor: new util.Color('gold'),
    opacity: 1.0, depth: -1, interpolate: true,
  });
  
  left_img_fb = new visual.ImageStim({
    win : psychoJS.window,
    name : 'left_img_fb', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [(- 0.25), 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  right_img_fb = new visual.ImageStim({
    win : psychoJS.window,
    name : 'right_img_fb', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0.25, 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  // Initialize components for Routine "outcome"
  outcomeClock = new util.Clock();
  photo_obj = new visual.ImageStim({
    win : psychoJS.window,
    name : 'photo_obj', units : 'height', 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [0.6, 0.4],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  frame_obj = new visual.ImageStim({
    win : psychoJS.window,
    name : 'frame_obj', units : 'height', 
    image : 'stimuli/frame.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [0.6, 0.56],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  // Initialize components for Routine "isi_break"
  isi_breakClock = new util.Clock();
  fix_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'fix_2',
    text: '+',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  rating_txt = new visual.TextStim({
    win: psychoJS.window,
    name: 'rating_txt',
    text: 'Round complete.\n\nPlease consider the previous two options and think about which you preferred to choose. On the next screen, you will be asked to select the option you prefer more.\n\nPress SPACE to continue.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  key_resp_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "img_rating"
  img_ratingClock = new util.Clock();
  rating_display = new visual.TextStim({
    win: psychoJS.window,
    name: 'rating_display',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.3], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  rating_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  left_img_rate = new visual.ImageStim({
    win : psychoJS.window,
    name : 'left_img_rate', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [(- 0.25), 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  right_img_rate = new visual.ImageStim({
    win : psychoJS.window,
    name : 'right_img_rate', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0.25, 0], size : [0.33, 0.33],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -4.0 
  });
  // Initialize components for Routine "take_break"
  take_breakClock = new util.Clock();
  break_txt_obj = new visual.TextStim({
    win: psychoJS.window,
    name: 'break_txt_obj',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  stop_break = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "exp_end"
  exp_endClock = new util.Clock();
  key_resp_6 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_4',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: 1,
    depth: -2.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var exp_startComponents;
function exp_startRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'exp_start' ---
    t = 0;
    exp_startClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('exp_start.started', globalClock.getTime());
    // keep track of which components have finished
    exp_startComponents = [];
    
    exp_startComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function exp_startRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'exp_start' ---
    // get current time
    t = exp_startClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from startup_code
    /* Syntax Error: Fix Python code */
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    exp_startComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var trials_filename;
function exp_startRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'exp_start' ---
    exp_startComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('exp_start.stopped', globalClock.getTime());
    // Run 'End Routine' code from load_trials
    if ((expInfo["prolific_id"] === "9999")) {
        orderID = 9999;
        trials_filename = `orders/sub-9999_task-filmreels_orders.csv`;
    } else {
        trials_filename = `orders/sub-${orderID}_task-filmreels_orders.csv`;
    }
    
    // the Routine "exp_start" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _agree_consent_allKeys;
var consentComponents;
function consentRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'consent' ---
    t = 0;
    consentClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('consent.started', globalClock.getTime());
    agree_consent.keys = undefined;
    agree_consent.rt = undefined;
    _agree_consent_allKeys = [];
    // keep track of which components have finished
    consentComponents = [];
    consentComponents.push(consent_text);
    consentComponents.push(continue_to_study);
    consentComponents.push(agree_consent);
    
    consentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function consentRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'consent' ---
    // get current time
    t = consentClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *consent_text* updates
    if (t >= 0.0 && consent_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      consent_text.tStart = t;  // (not accounting for frame time here)
      consent_text.frameNStart = frameN;  // exact frame index
      
      consent_text.setAutoDraw(true);
    }
    
    
    // *continue_to_study* updates
    if (t >= 3.0 && continue_to_study.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      continue_to_study.tStart = t;  // (not accounting for frame time here)
      continue_to_study.frameNStart = frameN;  // exact frame index
      
      continue_to_study.setAutoDraw(true);
    }
    
    
    // *agree_consent* updates
    if (t >= 3 && agree_consent.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      agree_consent.tStart = t;  // (not accounting for frame time here)
      agree_consent.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { agree_consent.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { agree_consent.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { agree_consent.clearEvents(); });
    }
    
    if (agree_consent.status === PsychoJS.Status.STARTED) {
      let theseKeys = agree_consent.getKeys({keyList: ['space'], waitRelease: false});
      _agree_consent_allKeys = _agree_consent_allKeys.concat(theseKeys);
      if (_agree_consent_allKeys.length > 0) {
        agree_consent.keys = _agree_consent_allKeys[_agree_consent_allKeys.length - 1].name;  // just the last key pressed
        agree_consent.rt = _agree_consent_allKeys[_agree_consent_allKeys.length - 1].rt;
        agree_consent.duration = _agree_consent_allKeys[_agree_consent_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    consentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function consentRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'consent' ---
    consentComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('consent.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(agree_consent.corr, level);
    }
    psychoJS.experiment.addData('agree_consent.keys', agree_consent.keys);
    if (typeof agree_consent.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('agree_consent.rt', agree_consent.rt);
        psychoJS.experiment.addData('agree_consent.duration', agree_consent.duration);
        routineTimer.reset();
        }
    
    agree_consent.stop();
    // the Routine "consent" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var instr_strs;
var instr_disp_txt;
var curr_instr;
var instr_back_txt;
var _instr_keyboard_allKeys;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    instructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // Run 'Begin Routine' code from instr_dict
    instr_strs = {};
    instr_strs[0] = `You have been recruited to curate a collection of photos. In this task, you will choose between different film reels to collect the most photos. At the end of the study, you will receive a bonus payment of $1 for every 20 photos you collect ($9 max). For example, you will receive a bonus payment of $3 if you collect 60 photos. You will receive a bonus payment of $5 if you collect 100 photos.`;
    instr_strs[1] = `On each trial, you will be presented with two photo film reel canisters (examples depicted below). You will choose one of them to collect the next photo in the film reel. You will have a limited number of opportunities to choose film reels, so please keep this in mind when making your choices.
    
    
    
    
    `;
    instr_strs[2] = `After you choose a film reel, the next frame in the reel will be displayed. If the next frame contains a photo (like the one below), it will be displayed and added to your photo collection. Please pay attention to the content in these photos.
    
    
    
    
    `;
    
    instr_strs[3] = `However, some of the frames do not contain photos. If the next frame does not contain a photo (like the one depicted below), then it will *NOT* be added to your collection. These will not count towards your bonus payment.
    
    
    
    
    `;
    
    instr_strs[4] = `As you complete the task, please keep in mind that some photo film reels contain more photos than others. You must use the information you have available throughout the task to learn which film reels are best to choose.`;
    instr_strs[5] = `Every so often, you will be asked to rate 'How much do you want social contact right now?' on a scale from 0 (Not at All) to 10 (Very Much). This refers to how much you want to interact with other people, such as friends, but can also refer to family members or even strangers. Please answer thoughtfully and honestly using your MOUSE.`;
    instr_strs[6] = `You have reached the end of the instructions. You may press the LEFT ARROW to review them again. You can press SPACE to practice.`;
    // Run 'Begin Routine' code from instr_both
    instr_disp_txt = new visual.TextStim({"win": psychoJS.window, "name": "instructions", "text": "", "font": "Arial", "pos": [0, 0], "height": 0.04, "wrapWidth": null, "ori": 0, "color": "black", "colorSpace": "rgb", "opacity": 1, "languageStyle": "LTR", "depth": 0.0});
    instr_disp_txt.text = instr_strs[0];
    instr_disp_txt.autoDraw = true;
    curr_instr = 0;
    instr_back_txt = new visual.TextStim({"win": psychoJS.window, "name": "back_forth", "text": "", "font": "Arial", "pos": [0, (- 0.4)], "height": 0.05, "wrapWidth": null, "ori": 0, "color": "black", "colorSpace": "rgb", "opacity": 1, "languageStyle": "LTR", "depth": 0.0});
    instr_back_txt.text = "\nPress RIGHT ARROW to continue";
    instr_back_txt.autoDraw = true;
    instr_keyboard.keys = undefined;
    instr_keyboard.rt = undefined;
    _instr_keyboard_allKeys = [];
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(instr_keyboard);
    
    instructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var _pj;
var instr_keys;
function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from instr_both
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    instr_keys = psychoJS.eventManager.getKeys();
    if ((curr_instr === 0)) {
        left_img_instr.autoDraw = false;
        right_img_instr.autoDraw = false;
        photo_obj_instr.autoDraw = false;
        blank_obj_instr.autoDraw = false;
        frame_obj_instr.autoDraw = false;
        instr_back_txt.text = "\nPress RIGHT ARROW to continue";
        if (_pj.in_es6("right", instr_keys)) {
            instr_keyboard.clearEvents();
            curr_instr += 1;
            instr_disp_txt.text = instr_strs[curr_instr];
            instr_back_txt.autoDraw = true;
        }
    } else {
        if ((curr_instr === 6)) {
            left_img_instr.autoDraw = false;
            right_img_instr.autoDraw = false;
            photo_obj_instr.autoDraw = false;
            blank_obj_instr.autoDraw = false;
            frame_obj_instr.autoDraw = false;
            instr_back_txt.text = "Press LEFT ARROW to go back\nPress SPACE to practice";
            if (_pj.in_es6("space", instr_keys)) {
                instr_keyboard.clearEvents();
                continueRoutine = false;
            } else {
                if (_pj.in_es6("left", instr_keys)) {
                    instr_keyboard.clearEvents();
                    curr_instr -= 1;
                    instr_disp_txt.text = instr_strs[curr_instr];
                    if ((curr_instr === 0)) {
                        instr_back_txt.autoDraw = false;
                    } else {
                        instr_back_txt.autoDraw = true;
                    }
                }
            }
        } else {
            if (curr_instr === 1) {
                left_img_instr.autoDraw = true;
                right_img_instr.autoDraw = true;
                photo_obj_instr.autoDraw = false;
                blank_obj_instr.autoDraw = false;
                frame_obj_instr.autoDraw = false;
            } else if (curr_instr === 2) {
                left_img_instr.autoDraw = false;
                right_img_instr.autoDraw = false;
                photo_obj_instr.autoDraw = true;
                blank_obj_instr.autoDraw = false;
                frame_obj_instr.autoDraw = true;
            } else if (curr_instr === 3) {
                left_img_instr.autoDraw = false;
                right_img_instr.autoDraw = false;
                photo_obj_instr.autoDraw = false;
                blank_obj_instr.autoDraw = true;
                frame_obj_instr.autoDraw = true;
            } else {
                left_img_instr.autoDraw = false;
                right_img_instr.autoDraw = false;
                photo_obj_instr.autoDraw = false;
                blank_obj_instr.autoDraw = false;
                frame_obj_instr.autoDraw = false;
            }
    
            instr_back_txt.text = "Press LEFT ARROW to go back\nPress RIGHT ARROW to continue";
            if (_pj.in_es6("right", instr_keys)) {
                instr_keyboard.clearEvents();
                curr_instr += 1;
                instr_disp_txt.text = instr_strs[curr_instr];
                instr_back_txt.autoDraw = true;
            } else {
                if (_pj.in_es6("left", instr_keys)) {
                    instr_keyboard.clearEvents();
                    curr_instr -= 1;
                    instr_disp_txt.text = instr_strs[curr_instr];
                    if ((curr_instr === 0)) {
                        instr_back_txt.text = "\nPress RIGHT ARROW to continue";
                    } else {
                        instr_back_txt.text = "Press LEFT ARROW to go back\nPress RIGHT ARROW to continue";
                    }
                }
            }
        }
    }
    
    
    // *instr_keyboard* updates
    if (t >= 0.0 && instr_keyboard.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_keyboard.tStart = t;  // (not accounting for frame time here)
      instr_keyboard.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { instr_keyboard.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { instr_keyboard.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { instr_keyboard.clearEvents(); });
    }
    
    if (instr_keyboard.status === PsychoJS.Status.STARTED) {
      let theseKeys = instr_keyboard.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _instr_keyboard_allKeys = _instr_keyboard_allKeys.concat(theseKeys);
      if (_instr_keyboard_allKeys.length > 0) {
        instr_keyboard.keys = _instr_keyboard_allKeys[_instr_keyboard_allKeys.length - 1].name;  // just the last key pressed
        instr_keyboard.rt = _instr_keyboard_allKeys[_instr_keyboard_allKeys.length - 1].rt;
        instr_keyboard.duration = _instr_keyboard_allKeys[_instr_keyboard_allKeys.length - 1].duration;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    instructionsComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // Run 'End Routine' code from instr_both
    instr_back_txt.autoDraw = false;
    instr_disp_txt.autoDraw = false;
    
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(instr_keyboard.corr, level);
    }
    psychoJS.experiment.addData('instr_keyboard.keys', instr_keyboard.keys);
    if (typeof instr_keyboard.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('instr_keyboard.rt', instr_keyboard.rt);
        psychoJS.experiment.addData('instr_keyboard.duration', instr_keyboard.duration);
        }
    
    instr_keyboard.stop();
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _begin_prac_allKeys;
var prac_startComponents;
function prac_startRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_start' ---
    t = 0;
    prac_startClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_start.started', globalClock.getTime());
    begin_prac.keys = undefined;
    begin_prac.rt = undefined;
    _begin_prac_allKeys = [];
    // Run 'Begin Routine' code from continue_arrow
    instr_back_txt.text = "\nPress SPACE to continue";
    instr_back_txt.autoDraw = true;
    
    // keep track of which components have finished
    prac_startComponents = [];
    prac_startComponents.push(prac_start_txt);
    prac_startComponents.push(begin_prac);
    
    prac_startComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_startRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_start' ---
    // get current time
    t = prac_startClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prac_start_txt* updates
    if (t >= 0.0 && prac_start_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_start_txt.tStart = t;  // (not accounting for frame time here)
      prac_start_txt.frameNStart = frameN;  // exact frame index
      
      prac_start_txt.setAutoDraw(true);
    }
    
    
    // *begin_prac* updates
    if (t >= 0.0 && begin_prac.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      begin_prac.tStart = t;  // (not accounting for frame time here)
      begin_prac.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { begin_prac.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { begin_prac.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { begin_prac.clearEvents(); });
    }
    
    if (begin_prac.status === PsychoJS.Status.STARTED) {
      let theseKeys = begin_prac.getKeys({keyList: ['space'], waitRelease: false});
      _begin_prac_allKeys = _begin_prac_allKeys.concat(theseKeys);
      if (_begin_prac_allKeys.length > 0) {
        begin_prac.keys = _begin_prac_allKeys[_begin_prac_allKeys.length - 1].name;  // just the last key pressed
        begin_prac.rt = _begin_prac_allKeys[_begin_prac_allKeys.length - 1].rt;
        begin_prac.duration = _begin_prac_allKeys[_begin_prac_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_startComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_startRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_start' ---
    prac_startComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_start.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(begin_prac.corr, level);
    }
    psychoJS.experiment.addData('begin_prac.keys', begin_prac.keys);
    if (typeof begin_prac.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('begin_prac.rt', begin_prac.rt);
        psychoJS.experiment.addData('begin_prac.duration', begin_prac.duration);
        routineTimer.reset();
        }
    
    begin_prac.stop();
    // Run 'End Routine' code from continue_arrow
    instr_back_txt.autoDraw = false;
    
    // the Routine "prac_start" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var prac_loop;
function prac_loopLoopBegin(prac_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    prac_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'prac_orders.csv',
      seed: undefined, name: 'prac_loop'
    });
    psychoJS.experiment.addLoop(prac_loop); // add the loop to the experiment
    currentLoop = prac_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    prac_loop.forEach(function() {
      snapshot = prac_loop.getSnapshot();
    
      prac_loopLoopScheduler.add(importConditions(snapshot));
      prac_loopLoopScheduler.add(prac_get_trial_infoRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(prac_get_trial_infoRoutineEachFrame());
      prac_loopLoopScheduler.add(prac_get_trial_infoRoutineEnd(snapshot));
      prac_loopLoopScheduler.add(prac_choiceRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(prac_choiceRoutineEachFrame());
      prac_loopLoopScheduler.add(prac_choiceRoutineEnd(snapshot));
      prac_loopLoopScheduler.add(prac_choice_feedbackRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(prac_choice_feedbackRoutineEachFrame());
      prac_loopLoopScheduler.add(prac_choice_feedbackRoutineEnd(snapshot));
      prac_loopLoopScheduler.add(isiRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(isiRoutineEachFrame());
      prac_loopLoopScheduler.add(isiRoutineEnd(snapshot));
      prac_loopLoopScheduler.add(prac_outcomeRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(prac_outcomeRoutineEachFrame());
      prac_loopLoopScheduler.add(prac_outcomeRoutineEnd(snapshot));
      const checkCravingRatePracLoopScheduler = new Scheduler(psychoJS);
      prac_loopLoopScheduler.add(checkCravingRatePracLoopBegin(checkCravingRatePracLoopScheduler, snapshot));
      prac_loopLoopScheduler.add(checkCravingRatePracLoopScheduler);
      prac_loopLoopScheduler.add(checkCravingRatePracLoopEnd);
      prac_loopLoopScheduler.add(prac_trial_fb_txtRoutineBegin(snapshot));
      prac_loopLoopScheduler.add(prac_trial_fb_txtRoutineEachFrame());
      prac_loopLoopScheduler.add(prac_trial_fb_txtRoutineEnd(snapshot));
      prac_loopLoopScheduler.add(prac_loopLoopEndIteration(prac_loopLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


var checkCravingRatePrac;
function checkCravingRatePracLoopBegin(checkCravingRatePracLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    checkCravingRatePrac = new TrialHandler({
      psychoJS: psychoJS,
      nReps: cravingRatingBoolPrac, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'checkCravingRatePrac'
    });
    psychoJS.experiment.addLoop(checkCravingRatePrac); // add the loop to the experiment
    currentLoop = checkCravingRatePrac;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    checkCravingRatePrac.forEach(function() {
      snapshot = checkCravingRatePrac.getSnapshot();
    
      checkCravingRatePracLoopScheduler.add(importConditions(snapshot));
      checkCravingRatePracLoopScheduler.add(isiRoutineBegin(snapshot));
      checkCravingRatePracLoopScheduler.add(isiRoutineEachFrame());
      checkCravingRatePracLoopScheduler.add(isiRoutineEnd(snapshot));
      checkCravingRatePracLoopScheduler.add(prac_cravingRoutineBegin(snapshot));
      checkCravingRatePracLoopScheduler.add(prac_cravingRoutineEachFrame());
      checkCravingRatePracLoopScheduler.add(prac_cravingRoutineEnd(snapshot));
      checkCravingRatePracLoopScheduler.add(checkCravingRatePracLoopEndIteration(checkCravingRatePracLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function checkCravingRatePracLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(checkCravingRatePrac);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function checkCravingRatePracLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function prac_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(prac_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function prac_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var quiz_loop;
function quiz_loopLoopBegin(quiz_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    quiz_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'quiz.csv',
      seed: undefined, name: 'quiz_loop'
    });
    psychoJS.experiment.addLoop(quiz_loop); // add the loop to the experiment
    currentLoop = quiz_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    quiz_loop.forEach(function() {
      snapshot = quiz_loop.getSnapshot();
    
      quiz_loopLoopScheduler.add(importConditions(snapshot));
      quiz_loopLoopScheduler.add(quiz_quesRoutineBegin(snapshot));
      quiz_loopLoopScheduler.add(quiz_quesRoutineEachFrame());
      quiz_loopLoopScheduler.add(quiz_quesRoutineEnd(snapshot));
      quiz_loopLoopScheduler.add(quiz_feedbackRoutineBegin(snapshot));
      quiz_loopLoopScheduler.add(quiz_feedbackRoutineEachFrame());
      quiz_loopLoopScheduler.add(quiz_feedbackRoutineEnd(snapshot));
      quiz_loopLoopScheduler.add(quiz_loopLoopEndIteration(quiz_loopLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function quiz_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(quiz_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function quiz_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: trials_filename,
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials.forEach(function() {
      snapshot = trials.getSnapshot();
    
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(get_trial_infoRoutineBegin(snapshot));
      trialsLoopScheduler.add(get_trial_infoRoutineEachFrame());
      trialsLoopScheduler.add(get_trial_infoRoutineEnd(snapshot));
      const checkCravingRate1LoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(checkCravingRate1LoopBegin(checkCravingRate1LoopScheduler, snapshot));
      trialsLoopScheduler.add(checkCravingRate1LoopScheduler);
      trialsLoopScheduler.add(checkCravingRate1LoopEnd);
      trialsLoopScheduler.add(isiRoutineBegin(snapshot));
      trialsLoopScheduler.add(isiRoutineEachFrame());
      trialsLoopScheduler.add(isiRoutineEnd(snapshot));
      trialsLoopScheduler.add(choiceRoutineBegin(snapshot));
      trialsLoopScheduler.add(choiceRoutineEachFrame());
      trialsLoopScheduler.add(choiceRoutineEnd(snapshot));
      trialsLoopScheduler.add(choice_feedbackRoutineBegin(snapshot));
      trialsLoopScheduler.add(choice_feedbackRoutineEachFrame());
      trialsLoopScheduler.add(choice_feedbackRoutineEnd(snapshot));
      trialsLoopScheduler.add(isiRoutineBegin(snapshot));
      trialsLoopScheduler.add(isiRoutineEachFrame());
      trialsLoopScheduler.add(isiRoutineEnd(snapshot));
      trialsLoopScheduler.add(outcomeRoutineBegin(snapshot));
      trialsLoopScheduler.add(outcomeRoutineEachFrame());
      trialsLoopScheduler.add(outcomeRoutineEnd(snapshot));
      const checkCravingRate2LoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(checkCravingRate2LoopBegin(checkCravingRate2LoopScheduler, snapshot));
      trialsLoopScheduler.add(checkCravingRate2LoopScheduler);
      trialsLoopScheduler.add(checkCravingRate2LoopEnd);
      const takeBreakLoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(takeBreakLoopBegin(takeBreakLoopScheduler, snapshot));
      trialsLoopScheduler.add(takeBreakLoopScheduler);
      trialsLoopScheduler.add(takeBreakLoopEnd);
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


var checkCravingRate1;
function checkCravingRate1LoopBegin(checkCravingRate1LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    checkCravingRate1 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: cravingRatingBool1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'checkCravingRate1'
    });
    psychoJS.experiment.addLoop(checkCravingRate1); // add the loop to the experiment
    currentLoop = checkCravingRate1;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    checkCravingRate1.forEach(function() {
      snapshot = checkCravingRate1.getSnapshot();
    
      checkCravingRate1LoopScheduler.add(importConditions(snapshot));
      checkCravingRate1LoopScheduler.add(isiRoutineBegin(snapshot));
      checkCravingRate1LoopScheduler.add(isiRoutineEachFrame());
      checkCravingRate1LoopScheduler.add(isiRoutineEnd(snapshot));
      checkCravingRate1LoopScheduler.add(cravingRoutineBegin(snapshot));
      checkCravingRate1LoopScheduler.add(cravingRoutineEachFrame());
      checkCravingRate1LoopScheduler.add(cravingRoutineEnd(snapshot));
      checkCravingRate1LoopScheduler.add(checkCravingRate1LoopEndIteration(checkCravingRate1LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function checkCravingRate1LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(checkCravingRate1);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function checkCravingRate1LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var checkCravingRate2;
function checkCravingRate2LoopBegin(checkCravingRate2LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    checkCravingRate2 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: cravingRatingBool2, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'checkCravingRate2'
    });
    psychoJS.experiment.addLoop(checkCravingRate2); // add the loop to the experiment
    currentLoop = checkCravingRate2;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    checkCravingRate2.forEach(function() {
      snapshot = checkCravingRate2.getSnapshot();
    
      checkCravingRate2LoopScheduler.add(importConditions(snapshot));
      checkCravingRate2LoopScheduler.add(isiRoutineBegin(snapshot));
      checkCravingRate2LoopScheduler.add(isiRoutineEachFrame());
      checkCravingRate2LoopScheduler.add(isiRoutineEnd(snapshot));
      checkCravingRate2LoopScheduler.add(cravingRoutineBegin(snapshot));
      checkCravingRate2LoopScheduler.add(cravingRoutineEachFrame());
      checkCravingRate2LoopScheduler.add(cravingRoutineEnd(snapshot));
      checkCravingRate2LoopScheduler.add(checkCravingRate2LoopEndIteration(checkCravingRate2LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function checkCravingRate2LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(checkCravingRate2);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function checkCravingRate2LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var takeBreak;
function takeBreakLoopBegin(takeBreakLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    takeBreak = new TrialHandler({
      psychoJS: psychoJS,
      nReps: takeBreakBool, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'takeBreak'
    });
    psychoJS.experiment.addLoop(takeBreak); // add the loop to the experiment
    currentLoop = takeBreak;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    takeBreak.forEach(function() {
      snapshot = takeBreak.getSnapshot();
    
      takeBreakLoopScheduler.add(importConditions(snapshot));
      takeBreakLoopScheduler.add(isi_breakRoutineBegin(snapshot));
      takeBreakLoopScheduler.add(isi_breakRoutineEachFrame());
      takeBreakLoopScheduler.add(isi_breakRoutineEnd(snapshot));
      takeBreakLoopScheduler.add(img_ratingRoutineBegin(snapshot));
      takeBreakLoopScheduler.add(img_ratingRoutineEachFrame());
      takeBreakLoopScheduler.add(img_ratingRoutineEnd(snapshot));
      const check_if_final_blockLoopScheduler = new Scheduler(psychoJS);
      takeBreakLoopScheduler.add(check_if_final_blockLoopBegin(check_if_final_blockLoopScheduler, snapshot));
      takeBreakLoopScheduler.add(check_if_final_blockLoopScheduler);
      takeBreakLoopScheduler.add(check_if_final_blockLoopEnd);
      takeBreakLoopScheduler.add(takeBreakLoopEndIteration(takeBreakLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


var check_if_final_block;
function check_if_final_blockLoopBegin(check_if_final_blockLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    check_if_final_block = new TrialHandler({
      psychoJS: psychoJS,
      nReps: take_break_bool, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'check_if_final_block'
    });
    psychoJS.experiment.addLoop(check_if_final_block); // add the loop to the experiment
    currentLoop = check_if_final_block;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    check_if_final_block.forEach(function() {
      snapshot = check_if_final_block.getSnapshot();
    
      check_if_final_blockLoopScheduler.add(importConditions(snapshot));
      check_if_final_blockLoopScheduler.add(take_breakRoutineBegin(snapshot));
      check_if_final_blockLoopScheduler.add(take_breakRoutineEachFrame());
      check_if_final_blockLoopScheduler.add(take_breakRoutineEnd(snapshot));
      check_if_final_blockLoopScheduler.add(check_if_final_blockLoopEndIteration(check_if_final_blockLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function check_if_final_blockLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(check_if_final_block);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function check_if_final_blockLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function takeBreakLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(takeBreak);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function takeBreakLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var cravingRatingBoolPrac;
var prac_get_trial_infoComponents;
function prac_get_trial_infoRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_get_trial_info' ---
    t = 0;
    prac_get_trial_infoClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_get_trial_info.started', globalClock.getTime());
    // Run 'Begin Routine' code from getCravingTrial_prac
    if ((rate_craving === 1)) {
        cravingRatingBoolPrac = 1;
    } else {
        cravingRatingBoolPrac = 0;
    }
    
    // keep track of which components have finished
    prac_get_trial_infoComponents = [];
    
    prac_get_trial_infoComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_get_trial_infoRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_get_trial_info' ---
    // get current time
    t = prac_get_trial_infoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_get_trial_infoComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_get_trial_infoRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_get_trial_info' ---
    prac_get_trial_infoComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_get_trial_info.stopped', globalClock.getTime());
    // the Routine "prac_get_trial_info" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _prac_resp_allKeys;
var prac_choiceComponents;
function prac_choiceRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_choice' ---
    t = 0;
    prac_choiceClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_choice.started', globalClock.getTime());
    left_img_2.setImage(stim_left);
    right_img_2.setImage(stim_right);
    prac_choice_instr.setText(prac_choice_instruction_txt);
    prac_resp.keys = undefined;
    prac_resp.rt = undefined;
    _prac_resp_allKeys = [];
    // keep track of which components have finished
    prac_choiceComponents = [];
    prac_choiceComponents.push(left_img_2);
    prac_choiceComponents.push(right_img_2);
    prac_choiceComponents.push(prac_choice_instr);
    prac_choiceComponents.push(prac_resp);
    
    prac_choiceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_choiceRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_choice' ---
    // get current time
    t = prac_choiceClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from store_chosen_stim_2
    if ((prac_allowed_key === "right")) {
        if ((prac_resp.keys === "right")) {
            continueRoutine = false;
        }
    } else {
        if ((prac_allowed_key === "left")) {
            if ((prac_resp.keys === "left")) {
                continueRoutine = false;
            }
        }
    }
    
    
    // *left_img_2* updates
    if (t >= 0 && left_img_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_img_2.tStart = t;  // (not accounting for frame time here)
      left_img_2.frameNStart = frameN;  // exact frame index
      
      left_img_2.setAutoDraw(true);
    }
    
    
    // *right_img_2* updates
    if (t >= 0 && right_img_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      right_img_2.tStart = t;  // (not accounting for frame time here)
      right_img_2.frameNStart = frameN;  // exact frame index
      
      right_img_2.setAutoDraw(true);
    }
    
    
    // *prac_choice_instr* updates
    if (t >= 0.0 && prac_choice_instr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_choice_instr.tStart = t;  // (not accounting for frame time here)
      prac_choice_instr.frameNStart = frameN;  // exact frame index
      
      prac_choice_instr.setAutoDraw(true);
    }
    
    
    // *prac_resp* updates
    if (t >= 0 && prac_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_resp.tStart = t;  // (not accounting for frame time here)
      prac_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { prac_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { prac_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { prac_resp.clearEvents(); });
    }
    
    if (prac_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = prac_resp.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _prac_resp_allKeys = _prac_resp_allKeys.concat(theseKeys);
      if (_prac_resp_allKeys.length > 0) {
        prac_resp.keys = _prac_resp_allKeys[_prac_resp_allKeys.length - 1].name;  // just the last key pressed
        prac_resp.rt = _prac_resp_allKeys[_prac_resp_allKeys.length - 1].rt;
        prac_resp.duration = _prac_resp_allKeys[_prac_resp_allKeys.length - 1].duration;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_choiceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var photo_cue_file_prac;
function prac_choiceRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_choice' ---
    prac_choiceComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_choice.stopped', globalClock.getTime());
    // Run 'End Routine' code from store_chosen_stim_2
    if ((prac_resp.keys === "left")) {
        if ((option_left === "A")) {
            photo_cue_file_prac = image_filename;
        } else {
            if ((option_left === "B")) {
                photo_cue_file_prac = "stimuli/blank.jpg";
            }
        }
    } else {
        if ((prac_resp.keys === "right")) {
            if ((option_right === "A")) {
                photo_cue_file_prac = image_filename;
            } else {
                if ((option_right === "B")) {
                    photo_cue_file_prac = "stimuli/blank.jpg";
                }
            }
        }
    }
    
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(prac_resp.corr, level);
    }
    psychoJS.experiment.addData('prac_resp.keys', prac_resp.keys);
    if (typeof prac_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('prac_resp.rt', prac_resp.rt);
        psychoJS.experiment.addData('prac_resp.duration', prac_resp.duration);
        }
    
    prac_resp.stop();
    // the Routine "prac_choice" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var outlinePos;
var prac_choice_feedbackComponents;
function prac_choice_feedbackRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_choice_feedback' ---
    t = 0;
    prac_choice_feedbackClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.500000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_choice_feedback.started', globalClock.getTime());
    // Run 'Begin Routine' code from get_chosen_3
    if ((prac_resp.keys === "left")) {
        outlinePos = [(- 0.25), 0];
    } else {
        if ((prac_resp.keys === "right")) {
            outlinePos = [0.25, 0];
        } else {
            outlinePos = [0.0, 4.0];
        }
    }
    
    square_3.setPos(outlinePos);
    left_img_fb_2.setImage(stim_left);
    right_img_fb_2.setImage(stim_right);
    // keep track of which components have finished
    prac_choice_feedbackComponents = [];
    prac_choice_feedbackComponents.push(square_3);
    prac_choice_feedbackComponents.push(left_img_fb_2);
    prac_choice_feedbackComponents.push(right_img_fb_2);
    
    prac_choice_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function prac_choice_feedbackRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_choice_feedback' ---
    // get current time
    t = prac_choice_feedbackClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *square_3* updates
    if (t >= 0.0 && square_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      square_3.tStart = t;  // (not accounting for frame time here)
      square_3.frameNStart = frameN;  // exact frame index
      
      square_3.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (square_3.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      square_3.setAutoDraw(false);
    }
    
    // *left_img_fb_2* updates
    if (t >= 0 && left_img_fb_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_img_fb_2.tStart = t;  // (not accounting for frame time here)
      left_img_fb_2.frameNStart = frameN;  // exact frame index
      
      left_img_fb_2.setAutoDraw(true);
    }
    
    frameRemains = 0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (left_img_fb_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      left_img_fb_2.setAutoDraw(false);
    }
    
    // *right_img_fb_2* updates
    if (t >= 0 && right_img_fb_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      right_img_fb_2.tStart = t;  // (not accounting for frame time here)
      right_img_fb_2.frameNStart = frameN;  // exact frame index
      
      right_img_fb_2.setAutoDraw(true);
    }
    
    frameRemains = 0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (right_img_fb_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      right_img_fb_2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_choice_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_choice_feedbackRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_choice_feedback' ---
    prac_choice_feedbackComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_choice_feedback.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var isiComponents;
function isiRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'isi' ---
    t = 0;
    isiClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('isi.started', globalClock.getTime());
    // keep track of which components have finished
    isiComponents = [];
    isiComponents.push(fix_rand);
    
    isiComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function isiRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'isi' ---
    // get current time
    t = isiClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fix_rand* updates
    if (t >= 0.0 && fix_rand.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fix_rand.tStart = t;  // (not accounting for frame time here)
      fix_rand.frameNStart = frameN;  // exact frame index
      
      fix_rand.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + ((0.1 * util.randint(0, 1)) + 0.5) - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (fix_rand.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      fix_rand.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    isiComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function isiRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'isi' ---
    isiComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('isi.stopped', globalClock.getTime());
    // the Routine "isi" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var prac_outcomeComponents;
function prac_outcomeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_outcome' ---
    t = 0;
    prac_outcomeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_outcome.started', globalClock.getTime());
    photo_obj_2.setImage(photo_cue_file_prac);
    // keep track of which components have finished
    prac_outcomeComponents = [];
    prac_outcomeComponents.push(photo_obj_2);
    prac_outcomeComponents.push(frame_obj_2);
    
    prac_outcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_outcomeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_outcome' ---
    // get current time
    t = prac_outcomeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *photo_obj_2* updates
    if (t >= 0.0 && photo_obj_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      photo_obj_2.tStart = t;  // (not accounting for frame time here)
      photo_obj_2.frameNStart = frameN;  // exact frame index
      
      photo_obj_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (photo_obj_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      photo_obj_2.setAutoDraw(false);
    }
    
    // *frame_obj_2* updates
    if (t >= 0.0 && frame_obj_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      frame_obj_2.tStart = t;  // (not accounting for frame time here)
      frame_obj_2.frameNStart = frameN;  // exact frame index
      
      frame_obj_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (frame_obj_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      frame_obj_2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_outcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_outcomeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_outcome' ---
    prac_outcomeComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_outcome.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _craving_kb_2_allKeys;
var prac_cravingComponents;
function prac_cravingRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_craving' ---
    t = 0;
    prac_cravingClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_craving.started', globalClock.getTime());
    socialCIC_slider_prac.reset()
    craving_kb_2.keys = undefined;
    craving_kb_2.rt = undefined;
    _craving_kb_2_allKeys = [];
    // Run 'Begin Routine' code from reset_mouse_pos_prac
    document.body.style.cursor='auto';
    // keep track of which components have finished
    prac_cravingComponents = [];
    prac_cravingComponents.push(socialCIC_slider_prac);
    prac_cravingComponents.push(social_contact_txt_2);
    prac_cravingComponents.push(ins_craving_rate_txt_2);
    prac_cravingComponents.push(craving_kb_2);
    
    prac_cravingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_cravingRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_craving' ---
    // get current time
    t = prac_cravingClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *socialCIC_slider_prac* updates
    if (t >= 0.0 && socialCIC_slider_prac.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      socialCIC_slider_prac.tStart = t;  // (not accounting for frame time here)
      socialCIC_slider_prac.frameNStart = frameN;  // exact frame index
      
      socialCIC_slider_prac.setAutoDraw(true);
    }
    
    
    // *social_contact_txt_2* updates
    if (t >= 0.0 && social_contact_txt_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      social_contact_txt_2.tStart = t;  // (not accounting for frame time here)
      social_contact_txt_2.frameNStart = frameN;  // exact frame index
      
      social_contact_txt_2.setAutoDraw(true);
    }
    
    
    // *ins_craving_rate_txt_2* updates
    if (t >= 0.0 && ins_craving_rate_txt_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ins_craving_rate_txt_2.tStart = t;  // (not accounting for frame time here)
      ins_craving_rate_txt_2.frameNStart = frameN;  // exact frame index
      
      ins_craving_rate_txt_2.setAutoDraw(true);
    }
    
    
    // *craving_kb_2* updates
    if ((socialCIC_slider_prac.rating) && craving_kb_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      craving_kb_2.tStart = t;  // (not accounting for frame time here)
      craving_kb_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { craving_kb_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { craving_kb_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { craving_kb_2.clearEvents(); });
    }
    
    if (craving_kb_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = craving_kb_2.getKeys({keyList: ['space'], waitRelease: false});
      _craving_kb_2_allKeys = _craving_kb_2_allKeys.concat(theseKeys);
      if (_craving_kb_2_allKeys.length > 0) {
        craving_kb_2.keys = _craving_kb_2_allKeys[_craving_kb_2_allKeys.length - 1].name;  // just the last key pressed
        craving_kb_2.rt = _craving_kb_2_allKeys[_craving_kb_2_allKeys.length - 1].rt;
        craving_kb_2.duration = _craving_kb_2_allKeys[_craving_kb_2_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_cravingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_cravingRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_craving' ---
    prac_cravingComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_craving.stopped', globalClock.getTime());
    psychoJS.experiment.addData('socialCIC_slider_prac.response', socialCIC_slider_prac.getRating());
    psychoJS.experiment.addData('socialCIC_slider_prac.rt', socialCIC_slider_prac.getRT());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(craving_kb_2.corr, level);
    }
    psychoJS.experiment.addData('craving_kb_2.keys', craving_kb_2.keys);
    if (typeof craving_kb_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('craving_kb_2.rt', craving_kb_2.rt);
        psychoJS.experiment.addData('craving_kb_2.duration', craving_kb_2.duration);
        routineTimer.reset();
        }
    
    craving_kb_2.stop();
    // Run 'End Routine' code from reset_mouse_pos_prac
    document.body.style.cursor='none';
    // the Routine "prac_craving" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _prac_continue_2_allKeys;
var prac_trial_fb_txtComponents;
function prac_trial_fb_txtRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'prac_trial_fb_txt' ---
    t = 0;
    prac_trial_fb_txtClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('prac_trial_fb_txt.started', globalClock.getTime());
    prac_trial_end_txt.setText(prac_feedback);
    prac_continue_2.keys = undefined;
    prac_continue_2.rt = undefined;
    _prac_continue_2_allKeys = [];
    // Run 'Begin Routine' code from continue_arrow_5
    instr_back_txt.autoDraw = true;
    
    // keep track of which components have finished
    prac_trial_fb_txtComponents = [];
    prac_trial_fb_txtComponents.push(prac_trial_end_txt);
    prac_trial_fb_txtComponents.push(prac_continue_2);
    
    prac_trial_fb_txtComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function prac_trial_fb_txtRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'prac_trial_fb_txt' ---
    // get current time
    t = prac_trial_fb_txtClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *prac_trial_end_txt* updates
    if (t >= 0.0 && prac_trial_end_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_trial_end_txt.tStart = t;  // (not accounting for frame time here)
      prac_trial_end_txt.frameNStart = frameN;  // exact frame index
      
      prac_trial_end_txt.setAutoDraw(true);
    }
    
    
    // *prac_continue_2* updates
    if (t >= 0.0 && prac_continue_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      prac_continue_2.tStart = t;  // (not accounting for frame time here)
      prac_continue_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { prac_continue_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { prac_continue_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { prac_continue_2.clearEvents(); });
    }
    
    if (prac_continue_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = prac_continue_2.getKeys({keyList: ['space'], waitRelease: false});
      _prac_continue_2_allKeys = _prac_continue_2_allKeys.concat(theseKeys);
      if (_prac_continue_2_allKeys.length > 0) {
        prac_continue_2.keys = _prac_continue_2_allKeys[_prac_continue_2_allKeys.length - 1].name;  // just the last key pressed
        prac_continue_2.rt = _prac_continue_2_allKeys[_prac_continue_2_allKeys.length - 1].rt;
        prac_continue_2.duration = _prac_continue_2_allKeys[_prac_continue_2_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    prac_trial_fb_txtComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function prac_trial_fb_txtRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'prac_trial_fb_txt' ---
    prac_trial_fb_txtComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('prac_trial_fb_txt.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(prac_continue_2.corr, level);
    }
    psychoJS.experiment.addData('prac_continue_2.keys', prac_continue_2.keys);
    if (typeof prac_continue_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('prac_continue_2.rt', prac_continue_2.rt);
        psychoJS.experiment.addData('prac_continue_2.duration', prac_continue_2.duration);
        routineTimer.reset();
        }
    
    prac_continue_2.stop();
    // Run 'End Routine' code from continue_arrow_5
    instr_back_txt.autoDraw = false;
    
    // the Routine "prac_trial_fb_txt" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _quiz_continue_allKeys;
var quizInstrComponents;
function quizInstrRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'quizInstr' ---
    t = 0;
    quizInstrClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('quizInstr.started', globalClock.getTime());
    quiz_continue.keys = undefined;
    quiz_continue.rt = undefined;
    _quiz_continue_allKeys = [];
    // Run 'Begin Routine' code from continue_arrow_4
    instr_back_txt.autoDraw = true;
    
    // keep track of which components have finished
    quizInstrComponents = [];
    quizInstrComponents.push(quiz_instr);
    quizInstrComponents.push(quiz_continue);
    
    quizInstrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function quizInstrRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'quizInstr' ---
    // get current time
    t = quizInstrClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *quiz_instr* updates
    if (t >= 0.0 && quiz_instr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quiz_instr.tStart = t;  // (not accounting for frame time here)
      quiz_instr.frameNStart = frameN;  // exact frame index
      
      quiz_instr.setAutoDraw(true);
    }
    
    
    // *quiz_continue* updates
    if (t >= 0.0 && quiz_continue.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quiz_continue.tStart = t;  // (not accounting for frame time here)
      quiz_continue.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { quiz_continue.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { quiz_continue.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { quiz_continue.clearEvents(); });
    }
    
    if (quiz_continue.status === PsychoJS.Status.STARTED) {
      let theseKeys = quiz_continue.getKeys({keyList: ['space'], waitRelease: false});
      _quiz_continue_allKeys = _quiz_continue_allKeys.concat(theseKeys);
      if (_quiz_continue_allKeys.length > 0) {
        quiz_continue.keys = _quiz_continue_allKeys[_quiz_continue_allKeys.length - 1].name;  // just the last key pressed
        quiz_continue.rt = _quiz_continue_allKeys[_quiz_continue_allKeys.length - 1].rt;
        quiz_continue.duration = _quiz_continue_allKeys[_quiz_continue_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    quizInstrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function quizInstrRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'quizInstr' ---
    quizInstrComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('quizInstr.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(quiz_continue.corr, level);
    }
    psychoJS.experiment.addData('quiz_continue.keys', quiz_continue.keys);
    if (typeof quiz_continue.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('quiz_continue.rt', quiz_continue.rt);
        psychoJS.experiment.addData('quiz_continue.duration', quiz_continue.duration);
        routineTimer.reset();
        }
    
    quiz_continue.stop();
    // Run 'End Routine' code from continue_arrow_4
    instr_back_txt.autoDraw = false;
    
    // the Routine "quizInstr" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _quizKeyboard_allKeys;
var quiz_quesComponents;
function quiz_quesRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'quiz_ques' ---
    t = 0;
    quiz_quesClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('quiz_ques.started', globalClock.getTime());
    quiz_q.setText(quizQuestion);
    quizKeyboard.keys = undefined;
    quizKeyboard.rt = undefined;
    _quizKeyboard_allKeys = [];
    // keep track of which components have finished
    quiz_quesComponents = [];
    quiz_quesComponents.push(quiz_q);
    quiz_quesComponents.push(quizKeyboard);
    quiz_quesComponents.push(true_or_false_txt);
    
    quiz_quesComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function quiz_quesRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'quiz_ques' ---
    // get current time
    t = quiz_quesClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *quiz_q* updates
    if (t >= 0.0 && quiz_q.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quiz_q.tStart = t;  // (not accounting for frame time here)
      quiz_q.frameNStart = frameN;  // exact frame index
      
      quiz_q.setAutoDraw(true);
    }
    
    
    // *quizKeyboard* updates
    if (t >= 0.0 && quizKeyboard.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quizKeyboard.tStart = t;  // (not accounting for frame time here)
      quizKeyboard.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { quizKeyboard.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { quizKeyboard.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { quizKeyboard.clearEvents(); });
    }
    
    if (quizKeyboard.status === PsychoJS.Status.STARTED) {
      let theseKeys = quizKeyboard.getKeys({keyList: ['t', 'f'], waitRelease: false});
      _quizKeyboard_allKeys = _quizKeyboard_allKeys.concat(theseKeys);
      if (_quizKeyboard_allKeys.length > 0) {
        quizKeyboard.keys = _quizKeyboard_allKeys[_quizKeyboard_allKeys.length - 1].name;  // just the last key pressed
        quizKeyboard.rt = _quizKeyboard_allKeys[_quizKeyboard_allKeys.length - 1].rt;
        quizKeyboard.duration = _quizKeyboard_allKeys[_quizKeyboard_allKeys.length - 1].duration;
        // was this correct?
        if (quizKeyboard.keys == quizCorrectAns) {
            quizKeyboard.corr = 1;
        } else {
            quizKeyboard.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *true_or_false_txt* updates
    if (t >= 0.0 && true_or_false_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      true_or_false_txt.tStart = t;  // (not accounting for frame time here)
      true_or_false_txt.frameNStart = frameN;  // exact frame index
      
      true_or_false_txt.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    quiz_quesComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function quiz_quesRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'quiz_ques' ---
    quiz_quesComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('quiz_ques.stopped', globalClock.getTime());
    // was no response the correct answer?!
    if (quizKeyboard.keys === undefined) {
      if (['None','none',undefined].includes(quizCorrectAns)) {
         quizKeyboard.corr = 1;  // correct non-response
      } else {
         quizKeyboard.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(quizKeyboard.corr, level);
    }
    psychoJS.experiment.addData('quizKeyboard.keys', quizKeyboard.keys);
    psychoJS.experiment.addData('quizKeyboard.corr', quizKeyboard.corr);
    if (typeof quizKeyboard.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('quizKeyboard.rt', quizKeyboard.rt);
        psychoJS.experiment.addData('quizKeyboard.duration', quizKeyboard.duration);
        routineTimer.reset();
        }
    
    quizKeyboard.stop();
    // the Routine "quiz_ques" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var quizResult;
var quizResultColor;
var _quizAdvance_allKeys;
var quiz_feedbackComponents;
function quiz_feedbackRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'quiz_feedback' ---
    t = 0;
    quiz_feedbackClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('quiz_feedback.started', globalClock.getTime());
    // Run 'Begin Routine' code from check_correct
    if (quizKeyboard.corr) {
        quizResult = "CORRECT!";
        quizResultColor = "green";
    } else {
        quizResult = "INCORRECT!";
        quizResultColor = "red";
    }
    
    CORRECT_OR_INCORRECT.setColor(new util.Color(quizResultColor));
    CORRECT_OR_INCORRECT.setText(quizResult);
    quiz_feedback_text.setText(quizFeedback);
    quizAdvance.keys = undefined;
    quizAdvance.rt = undefined;
    _quizAdvance_allKeys = [];
    // Run 'Begin Routine' code from continue_arrow_3
    instr_back_txt.autoDraw = true;
    
    // keep track of which components have finished
    quiz_feedbackComponents = [];
    quiz_feedbackComponents.push(CORRECT_OR_INCORRECT);
    quiz_feedbackComponents.push(quiz_feedback_text);
    quiz_feedbackComponents.push(quizAdvance);
    
    quiz_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function quiz_feedbackRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'quiz_feedback' ---
    // get current time
    t = quiz_feedbackClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *CORRECT_OR_INCORRECT* updates
    if (t >= 0.0 && CORRECT_OR_INCORRECT.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      CORRECT_OR_INCORRECT.tStart = t;  // (not accounting for frame time here)
      CORRECT_OR_INCORRECT.frameNStart = frameN;  // exact frame index
      
      CORRECT_OR_INCORRECT.setAutoDraw(true);
    }
    
    
    // *quiz_feedback_text* updates
    if (t >= 0.0 && quiz_feedback_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quiz_feedback_text.tStart = t;  // (not accounting for frame time here)
      quiz_feedback_text.frameNStart = frameN;  // exact frame index
      
      quiz_feedback_text.setAutoDraw(true);
    }
    
    
    // *quizAdvance* updates
    if (t >= 0.5 && quizAdvance.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quizAdvance.tStart = t;  // (not accounting for frame time here)
      quizAdvance.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { quizAdvance.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { quizAdvance.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { quizAdvance.clearEvents(); });
    }
    
    if (quizAdvance.status === PsychoJS.Status.STARTED) {
      let theseKeys = quizAdvance.getKeys({keyList: ['space'], waitRelease: false});
      _quizAdvance_allKeys = _quizAdvance_allKeys.concat(theseKeys);
      if (_quizAdvance_allKeys.length > 0) {
        quizAdvance.keys = _quizAdvance_allKeys[_quizAdvance_allKeys.length - 1].name;  // just the last key pressed
        quizAdvance.rt = _quizAdvance_allKeys[_quizAdvance_allKeys.length - 1].rt;
        quizAdvance.duration = _quizAdvance_allKeys[_quizAdvance_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    quiz_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function quiz_feedbackRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'quiz_feedback' ---
    quiz_feedbackComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('quiz_feedback.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(quizAdvance.corr, level);
    }
    psychoJS.experiment.addData('quizAdvance.keys', quizAdvance.keys);
    if (typeof quizAdvance.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('quizAdvance.rt', quizAdvance.rt);
        psychoJS.experiment.addData('quizAdvance.duration', quizAdvance.duration);
        routineTimer.reset();
        }
    
    quizAdvance.stop();
    // Run 'End Routine' code from continue_arrow_3
    instr_back_txt.autoDraw = false;
    
    // the Routine "quiz_feedback" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_advance_allKeys;
var get_readyComponents;
function get_readyRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'get_ready' ---
    t = 0;
    get_readyClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('get_ready.started', globalClock.getTime());
    key_advance.keys = undefined;
    key_advance.rt = undefined;
    _key_advance_allKeys = [];
    // keep track of which components have finished
    get_readyComponents = [];
    get_readyComponents.push(waiting);
    get_readyComponents.push(key_advance);
    
    get_readyComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function get_readyRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'get_ready' ---
    // get current time
    t = get_readyClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *waiting* updates
    if (t >= 0.0 && waiting.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      waiting.tStart = t;  // (not accounting for frame time here)
      waiting.frameNStart = frameN;  // exact frame index
      
      waiting.setAutoDraw(true);
    }
    
    
    // *key_advance* updates
    if (t >= 0.0 && key_advance.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_advance.tStart = t;  // (not accounting for frame time here)
      key_advance.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_advance.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_advance.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_advance.clearEvents(); });
    }
    
    if (key_advance.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_advance.getKeys({keyList: [], waitRelease: false});
      _key_advance_allKeys = _key_advance_allKeys.concat(theseKeys);
      if (_key_advance_allKeys.length > 0) {
        key_advance.keys = _key_advance_allKeys[_key_advance_allKeys.length - 1].name;  // just the last key pressed
        key_advance.rt = _key_advance_allKeys[_key_advance_allKeys.length - 1].rt;
        key_advance.duration = _key_advance_allKeys[_key_advance_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    get_readyComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function get_readyRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'get_ready' ---
    get_readyComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('get_ready.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(key_advance.corr, level);
    }
    psychoJS.experiment.addData('key_advance.keys', key_advance.keys);
    if (typeof key_advance.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_advance.rt', key_advance.rt);
        psychoJS.experiment.addData('key_advance.duration', key_advance.duration);
        routineTimer.reset();
        }
    
    key_advance.stop();
    // the Routine "get_ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var cravingRatingBool1;
var cravingRatingBool2;
var takeBreakBool;
var trialsocialPts;
var trialfoodPts;
var trialnaturePts;
var trialcumulPts;
var get_trial_infoComponents;
function get_trial_infoRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'get_trial_info' ---
    t = 0;
    get_trial_infoClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('get_trial_info.started', globalClock.getTime());
    // Run 'Begin Routine' code from getCravingTrial
    if ((trials.thisTrialN === 0)) {
        cravingRatingBool1 = 1;
    } else {
        cravingRatingBool1 = 0;
    }
    if ((rate_craving === 1)) {
        cravingRatingBool2 = 1;
    } else {
        cravingRatingBool2 = 0;
    }
    
    // Run 'Begin Routine' code from getBreakTrial
    if ((trialIndex === 15)) {
        takeBreakBool = 1;
    } else {
        takeBreakBool = 0;
    }
    
    // Run 'Begin Routine' code from reset_points
    console.log(`trial=${trialIndex}`);
    if ((trialIndex === 0)) {
        trialsocialPts = 0;
        trialfoodPts = 0;
        trialnaturePts = 0;
        trialcumulPts = 0;
    }
    
    // keep track of which components have finished
    get_trial_infoComponents = [];
    
    get_trial_infoComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function get_trial_infoRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'get_trial_info' ---
    // get current time
    t = get_trial_infoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    get_trial_infoComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var final_trial_in_block;
function get_trial_infoRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'get_trial_info' ---
    get_trial_infoComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('get_trial_info.stopped', globalClock.getTime());
    // Run 'End Routine' code from get_stim_showed
    if ((trialIndex === 191)) {
        final_trial_in_block = 1;
    } else {
        final_trial_in_block = 0;
    }
    if ((orderID === 9999)) {
        if ((trialIndex === 143)) {
            final_trial_in_block = 1;
        } else {
            final_trial_in_block = 0;
        }
    }
    
    // the Routine "get_trial_info" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _craving_kb_allKeys;
var cravingComponents;
function cravingRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'craving' ---
    t = 0;
    cravingClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('craving.started', globalClock.getTime());
    socialCIC_slider.reset()
    craving_kb.keys = undefined;
    craving_kb.rt = undefined;
    _craving_kb_allKeys = [];
    // Run 'Begin Routine' code from reset_mouse_pos
    document.body.style.cursor='auto';
    // keep track of which components have finished
    cravingComponents = [];
    cravingComponents.push(socialCIC_slider);
    cravingComponents.push(social_contact_txt);
    cravingComponents.push(ins_craving_rate_txt);
    cravingComponents.push(craving_kb);
    
    cravingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function cravingRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'craving' ---
    // get current time
    t = cravingClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *socialCIC_slider* updates
    if (t >= 0 && socialCIC_slider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      socialCIC_slider.tStart = t;  // (not accounting for frame time here)
      socialCIC_slider.frameNStart = frameN;  // exact frame index
      
      socialCIC_slider.setAutoDraw(true);
    }
    
    
    // *social_contact_txt* updates
    if (t >= 0.0 && social_contact_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      social_contact_txt.tStart = t;  // (not accounting for frame time here)
      social_contact_txt.frameNStart = frameN;  // exact frame index
      
      social_contact_txt.setAutoDraw(true);
    }
    
    
    // *ins_craving_rate_txt* updates
    if (t >= 0.0 && ins_craving_rate_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ins_craving_rate_txt.tStart = t;  // (not accounting for frame time here)
      ins_craving_rate_txt.frameNStart = frameN;  // exact frame index
      
      ins_craving_rate_txt.setAutoDraw(true);
    }
    
    
    // *craving_kb* updates
    if ((socialCIC_slider.rating) && craving_kb.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      craving_kb.tStart = t;  // (not accounting for frame time here)
      craving_kb.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { craving_kb.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { craving_kb.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { craving_kb.clearEvents(); });
    }
    
    if (craving_kb.status === PsychoJS.Status.STARTED) {
      let theseKeys = craving_kb.getKeys({keyList: ['space'], waitRelease: false});
      _craving_kb_allKeys = _craving_kb_allKeys.concat(theseKeys);
      if (_craving_kb_allKeys.length > 0) {
        craving_kb.keys = _craving_kb_allKeys[_craving_kb_allKeys.length - 1].name;  // just the last key pressed
        craving_kb.rt = _craving_kb_allKeys[_craving_kb_allKeys.length - 1].rt;
        craving_kb.duration = _craving_kb_allKeys[_craving_kb_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    cravingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function cravingRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'craving' ---
    cravingComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('craving.stopped', globalClock.getTime());
    psychoJS.experiment.addData('socialCIC_slider.response', socialCIC_slider.getRating());
    psychoJS.experiment.addData('socialCIC_slider.rt', socialCIC_slider.getRT());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(craving_kb.corr, level);
    }
    psychoJS.experiment.addData('craving_kb.keys', craving_kb.keys);
    if (typeof craving_kb.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('craving_kb.rt', craving_kb.rt);
        psychoJS.experiment.addData('craving_kb.duration', craving_kb.duration);
        routineTimer.reset();
        }
    
    craving_kb.stop();
    // Run 'End Routine' code from reset_mouse_pos
    document.body.style.cursor='none';
    // the Routine "craving" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_allKeys;
var choiceComponents;
function choiceRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'choice' ---
    t = 0;
    choiceClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('choice.started', globalClock.getTime());
    left_img.setImage(stim_left);
    right_img.setImage(stim_right);
    key_resp.keys = undefined;
    key_resp.rt = undefined;
    _key_resp_allKeys = [];
    // keep track of which components have finished
    choiceComponents = [];
    choiceComponents.push(left_img);
    choiceComponents.push(right_img);
    choiceComponents.push(key_resp);
    
    choiceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function choiceRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'choice' ---
    // get current time
    t = choiceClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *left_img* updates
    if (t >= 0 && left_img.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_img.tStart = t;  // (not accounting for frame time here)
      left_img.frameNStart = frameN;  // exact frame index
      
      left_img.setAutoDraw(true);
    }
    
    
    // *right_img* updates
    if (t >= 0 && right_img.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      right_img.tStart = t;  // (not accounting for frame time here)
      right_img.frameNStart = frameN;  // exact frame index
      
      right_img.setAutoDraw(true);
    }
    
    
    // *key_resp* updates
    if (t >= 0 && key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp.tStart = t;  // (not accounting for frame time here)
      key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp.clearEvents(); });
    }
    
    if (key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _key_resp_allKeys = _key_resp_allKeys.concat(theseKeys);
      if (_key_resp_allKeys.length > 0) {
        key_resp.keys = _key_resp_allKeys[_key_resp_allKeys.length - 1].name;  // just the last key pressed
        key_resp.rt = _key_resp_allKeys[_key_resp_allKeys.length - 1].rt;
        key_resp.duration = _key_resp_allKeys[_key_resp_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    choiceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var this_outcome;
var photo_cue_file;
function choiceRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'choice' ---
    choiceComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('choice.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(key_resp.corr, level);
    }
    psychoJS.experiment.addData('key_resp.keys', key_resp.keys);
    if (typeof key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp.rt', key_resp.rt);
        psychoJS.experiment.addData('key_resp.duration', key_resp.duration);
        routineTimer.reset();
        }
    
    key_resp.stop();
    // Run 'End Routine' code from store_chosen_stim
    if ((key_resp.keys === "left")) {
        psychoJS.experiment.addData("chosen_file", stim_left);
        psychoJS.experiment.addData("chosen_stim", option_left);
        if ((option_left === "A")) {
            this_outcome = A_outcome;
            psychoJS.experiment.addData("outcome", this_outcome);
        } else {
            if ((option_left === "B")) {
                this_outcome = B_outcome;
                psychoJS.experiment.addData("outcome", this_outcome);
            }
        }
    } else {
        if ((key_resp.keys === "right")) {
            psychoJS.experiment.addData("chosen_file", stim_right);
            psychoJS.experiment.addData("chosen_stim", option_right);
            if ((option_right === "A")) {
                this_outcome = A_outcome;
                psychoJS.experiment.addData("outcome", this_outcome);
            } else {
                if ((option_right === "B")) {
                    this_outcome = B_outcome;
                    psychoJS.experiment.addData("outcome", this_outcome);
                }
            }
        }
    }
    if ((this_outcome === 0)) {
        photo_cue_file = "stimuli/blank.jpg";
    } else {
        if ((this_outcome === 1)) {
            photo_cue_file = image_filename;
            cumulPts += 1;
            trialcumulPts += 1;
            if ((condition === "social")) {
                socialPts += 1;
                trialsocialPts += 1;
            } else {
                if ((condition === "food")) {
                    foodPts += 1;
                    trialfoodPts += 1;
                } else {
                    if ((condition === "nature")) {
                        naturePts += 1;
                        trialnaturePts += 1;
                    }
                }
            }
        }
    }
    psychoJS.experiment.addData("socialPts", socialPts);
    psychoJS.experiment.addData("trialsocialPts", trialsocialPts);
    psychoJS.experiment.addData("foodPts", foodPts);
    psychoJS.experiment.addData("trialfoodPts", trialfoodPts);
    psychoJS.experiment.addData("naturePts", naturePts);
    psychoJS.experiment.addData("trialnaturePts", trialnaturePts);
    psychoJS.experiment.addData("cumulPts", cumulPts);
    psychoJS.experiment.addData("trialPts", trialcumulPts);
    
    // the Routine "choice" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var choice_feedbackComponents;
function choice_feedbackRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'choice_feedback' ---
    t = 0;
    choice_feedbackClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.500000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('choice_feedback.started', globalClock.getTime());
    // Run 'Begin Routine' code from get_chosen
    if ((key_resp.keys === "left")) {
        outlinePos = [(- 0.25), 0];
    } else {
        if ((key_resp.keys === "right")) {
            outlinePos = [0.25, 0];
        } else {
            outlinePos = [0.0, 4.0];
        }
    }
    
    square.setPos(outlinePos);
    left_img_fb.setImage(stim_left);
    right_img_fb.setImage(stim_right);
    // keep track of which components have finished
    choice_feedbackComponents = [];
    choice_feedbackComponents.push(square);
    choice_feedbackComponents.push(left_img_fb);
    choice_feedbackComponents.push(right_img_fb);
    
    choice_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function choice_feedbackRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'choice_feedback' ---
    // get current time
    t = choice_feedbackClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *square* updates
    if (t >= 0.0 && square.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      square.tStart = t;  // (not accounting for frame time here)
      square.frameNStart = frameN;  // exact frame index
      
      square.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (square.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      square.setAutoDraw(false);
    }
    
    // *left_img_fb* updates
    if (t >= 0 && left_img_fb.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_img_fb.tStart = t;  // (not accounting for frame time here)
      left_img_fb.frameNStart = frameN;  // exact frame index
      
      left_img_fb.setAutoDraw(true);
    }
    
    frameRemains = 0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (left_img_fb.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      left_img_fb.setAutoDraw(false);
    }
    
    // *right_img_fb* updates
    if (t >= 0 && right_img_fb.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      right_img_fb.tStart = t;  // (not accounting for frame time here)
      right_img_fb.frameNStart = frameN;  // exact frame index
      
      right_img_fb.setAutoDraw(true);
    }
    
    frameRemains = 0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (right_img_fb.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      right_img_fb.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    choice_feedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function choice_feedbackRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'choice_feedback' ---
    choice_feedbackComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('choice_feedback.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var outcomeComponents;
function outcomeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'outcome' ---
    t = 0;
    outcomeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('outcome.started', globalClock.getTime());
    photo_obj.setImage(photo_cue_file);
    // keep track of which components have finished
    outcomeComponents = [];
    outcomeComponents.push(photo_obj);
    outcomeComponents.push(frame_obj);
    
    outcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function outcomeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'outcome' ---
    // get current time
    t = outcomeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *photo_obj* updates
    if (t >= 0.0 && photo_obj.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      photo_obj.tStart = t;  // (not accounting for frame time here)
      photo_obj.frameNStart = frameN;  // exact frame index
      
      photo_obj.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (photo_obj.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      photo_obj.setAutoDraw(false);
    }
    
    // *frame_obj* updates
    if (t >= 0.0 && frame_obj.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      frame_obj.tStart = t;  // (not accounting for frame time here)
      frame_obj.frameNStart = frameN;  // exact frame index
      
      frame_obj.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (frame_obj.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      frame_obj.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    outcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function outcomeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'outcome' ---
    outcomeComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('outcome.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_2_allKeys;
var isi_breakComponents;
function isi_breakRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'isi_break' ---
    t = 0;
    isi_breakClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('isi_break.started', globalClock.getTime());
    key_resp_2.keys = undefined;
    key_resp_2.rt = undefined;
    _key_resp_2_allKeys = [];
    // keep track of which components have finished
    isi_breakComponents = [];
    isi_breakComponents.push(fix_2);
    isi_breakComponents.push(rating_txt);
    isi_breakComponents.push(key_resp_2);
    
    isi_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function isi_breakRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'isi_break' ---
    // get current time
    t = isi_breakClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *fix_2* updates
    if (t >= 0.0 && fix_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fix_2.tStart = t;  // (not accounting for frame time here)
      fix_2.frameNStart = frameN;  // exact frame index
      
      fix_2.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (fix_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      fix_2.setAutoDraw(false);
    }
    
    // *rating_txt* updates
    if (t >= 1 && rating_txt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rating_txt.tStart = t;  // (not accounting for frame time here)
      rating_txt.frameNStart = frameN;  // exact frame index
      
      rating_txt.setAutoDraw(true);
    }
    
    
    // *key_resp_2* updates
    if (t >= 1 && key_resp_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_2.tStart = t;  // (not accounting for frame time here)
      key_resp_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.clearEvents(); });
    }
    
    if (key_resp_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_2.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_2_allKeys = _key_resp_2_allKeys.concat(theseKeys);
      if (_key_resp_2_allKeys.length > 0) {
        key_resp_2.keys = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].name;  // just the last key pressed
        key_resp_2.rt = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].rt;
        key_resp_2.duration = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    isi_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function isi_breakRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'isi_break' ---
    isi_breakComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('isi_break.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(key_resp_2.corr, level);
    }
    psychoJS.experiment.addData('key_resp_2.keys', key_resp_2.keys);
    if (typeof key_resp_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_2.rt', key_resp_2.rt);
        psychoJS.experiment.addData('key_resp_2.duration', key_resp_2.duration);
        routineTimer.reset();
        }
    
    key_resp_2.stop();
    // the Routine "isi_break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var rating_text;
var _rating_resp_allKeys;
var img_ratingComponents;
function img_ratingRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'img_rating' ---
    t = 0;
    img_ratingClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('img_rating.started', globalClock.getTime());
    // Run 'Begin Routine' code from get_reel_ratings
    rating_text = "Please think about which option you prefer more. Then select it below.";
    
    rating_display.setText(rating_text);
    rating_resp.keys = undefined;
    rating_resp.rt = undefined;
    _rating_resp_allKeys = [];
    left_img_rate.setImage(stim_left);
    right_img_rate.setImage(stim_right);
    // keep track of which components have finished
    img_ratingComponents = [];
    img_ratingComponents.push(rating_display);
    img_ratingComponents.push(rating_resp);
    img_ratingComponents.push(left_img_rate);
    img_ratingComponents.push(right_img_rate);
    
    img_ratingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function img_ratingRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'img_rating' ---
    // get current time
    t = img_ratingClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *rating_display* updates
    if (t >= 0.0 && rating_display.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rating_display.tStart = t;  // (not accounting for frame time here)
      rating_display.frameNStart = frameN;  // exact frame index
      
      rating_display.setAutoDraw(true);
    }
    
    
    // *rating_resp* updates
    if (t >= 0 && rating_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rating_resp.tStart = t;  // (not accounting for frame time here)
      rating_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { rating_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { rating_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { rating_resp.clearEvents(); });
    }
    
    if (rating_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = rating_resp.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _rating_resp_allKeys = _rating_resp_allKeys.concat(theseKeys);
      if (_rating_resp_allKeys.length > 0) {
        rating_resp.keys = _rating_resp_allKeys[_rating_resp_allKeys.length - 1].name;  // just the last key pressed
        rating_resp.rt = _rating_resp_allKeys[_rating_resp_allKeys.length - 1].rt;
        rating_resp.duration = _rating_resp_allKeys[_rating_resp_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *left_img_rate* updates
    if (t >= 0 && left_img_rate.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_img_rate.tStart = t;  // (not accounting for frame time here)
      left_img_rate.frameNStart = frameN;  // exact frame index
      
      left_img_rate.setAutoDraw(true);
    }
    
    
    // *right_img_rate* updates
    if (t >= 0 && right_img_rate.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      right_img_rate.tStart = t;  // (not accounting for frame time here)
      right_img_rate.frameNStart = frameN;  // exact frame index
      
      right_img_rate.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    img_ratingComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var take_break_bool;
function img_ratingRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'img_rating' ---
    img_ratingComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('img_rating.stopped', globalClock.getTime());
    // Run 'End Routine' code from get_reel_ratings
    if ((rating_resp.keys === "left")) {
        psychoJS.experiment.addData("best_rating", option_left);
        psychoJS.experiment.addData("best_stim", stim_left);
        psychoJS.experiment.addData("worst_rating", option_right);
        psychoJS.experiment.addData("worst_stim", stim_right);
    } else {
        if ((rating_resp.keys === "right")) {
            psychoJS.experiment.addData("best_rating", option_right);
            psychoJS.experiment.addData("best_stim", stim_right);
            psychoJS.experiment.addData("worst_rating", option_left);
            psychoJS.experiment.addData("worst_stim", stim_left);
        }
    }
    take_break_bool = 1;
    if ((blockIndex === 11)) {
        take_break_bool = 0;
    }
    
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(rating_resp.corr, level);
    }
    psychoJS.experiment.addData('rating_resp.keys', rating_resp.keys);
    if (typeof rating_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('rating_resp.rt', rating_resp.rt);
        psychoJS.experiment.addData('rating_resp.duration', rating_resp.duration);
        routineTimer.reset();
        }
    
    rating_resp.stop();
    // the Routine "img_rating" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var break_txt_to_disp;
var _stop_break_allKeys;
var take_breakComponents;
function take_breakRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'take_break' ---
    t = 0;
    take_breakClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('take_break.started', globalClock.getTime());
    // Run 'Begin Routine' code from set_break_txt
    break_txt_to_disp = `Round ${(blockIndex + 1)} of 12 completed!
    Please take a short break.
    
    
    Press SPACE when you are ready to continue.`
    ;
    
    break_txt_obj.setText(break_txt_to_disp);
    stop_break.keys = undefined;
    stop_break.rt = undefined;
    _stop_break_allKeys = [];
    // keep track of which components have finished
    take_breakComponents = [];
    take_breakComponents.push(break_txt_obj);
    take_breakComponents.push(stop_break);
    
    take_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function take_breakRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'take_break' ---
    // get current time
    t = take_breakClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *break_txt_obj* updates
    if (t >= 0.0 && break_txt_obj.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      break_txt_obj.tStart = t;  // (not accounting for frame time here)
      break_txt_obj.frameNStart = frameN;  // exact frame index
      
      break_txt_obj.setAutoDraw(true);
    }
    
    
    // *stop_break* updates
    if (t >= 0.0 && stop_break.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      stop_break.tStart = t;  // (not accounting for frame time here)
      stop_break.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { stop_break.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { stop_break.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { stop_break.clearEvents(); });
    }
    
    if (stop_break.status === PsychoJS.Status.STARTED) {
      let theseKeys = stop_break.getKeys({keyList: ['space'], waitRelease: false});
      _stop_break_allKeys = _stop_break_allKeys.concat(theseKeys);
      if (_stop_break_allKeys.length > 0) {
        stop_break.keys = _stop_break_allKeys[_stop_break_allKeys.length - 1].name;  // just the last key pressed
        stop_break.rt = _stop_break_allKeys[_stop_break_allKeys.length - 1].rt;
        stop_break.duration = _stop_break_allKeys[_stop_break_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    take_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function take_breakRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'take_break' ---
    take_breakComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('take_break.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(stop_break.corr, level);
    }
    psychoJS.experiment.addData('stop_break.keys', stop_break.keys);
    if (typeof stop_break.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('stop_break.rt', stop_break.rt);
        psychoJS.experiment.addData('stop_break.duration', stop_break.duration);
        routineTimer.reset();
        }
    
    stop_break.stop();
    // the Routine "take_break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var moneySelf;
var end_result_self;
var ender_text;
var _key_resp_6_allKeys;
var myCompletedURL;
var myCancelledURL;
var exp_endComponents;
function exp_endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'exp_end' ---
    t = 0;
    exp_endClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('exp_end.started', globalClock.getTime());
    // Run 'Begin Routine' code from getFinalPoints
    if ((cumulPts > 0)) {
        moneySelf = (0.05 * cumulPts);
        if ((moneySelf > 9)) {
            moneySelf = 9;
        }
        end_result_self = `You earned ${cumulPts} points ($${util.pad(Number.parseFloat(moneySelf).toFixed(2), 1)})`;
    } else {
        moneySelf = 0;
        if ((ptsSelf === 0)) {
            end_result_self = `You earned 0 points ($${util.pad(Number.parseFloat(moneySelf).toFixed(2), 1)})`;
        }
    }
    ender_text = `All rounds completed!
    
    
    
    Press SPACE to continue onto part 2 of the study.`
    ;
    
    key_resp_6.keys = undefined;
    key_resp_6.rt = undefined;
    _key_resp_6_allKeys = [];
    text_4.setText(ender_text);
    //util.addInfoFromUrl(moneySelf);
    //util.addInfoFromUrl(moneyOther);
    //util.addInfoFromUrl(ptsSelf);
    //util.addInfoFromUrl(ptsOther);
    //util.addInfoFromUrl(subjectID);
    
    myCompletedURL = "https://redcap.mountsinai.org/redcap/surveys/?s=PKFDMEK9FFM3HYXL&prolific_id="+expInfo['prolific_id']+"&order_id="+orderID+"&study_id="+expInfo['study_id']+"&session_id="+expInfo['session_id']+"&selfm="+moneySelf+"&spts="+socialPts+"&npts="+naturePts+"&fpts="+foodPts;
    myCancelledURL = "https://redcap.mountsinai.org/redcap/surveys/?s=PKFDMEK9FFM3HYXL";
    psychoJS.setRedirectUrls(myCompletedURL, myCancelledURL)
    // Run 'Begin Routine' code from add_new_expInfo
    expInfo["order_id"] = orderID;
    
    // keep track of which components have finished
    exp_endComponents = [];
    exp_endComponents.push(key_resp_6);
    exp_endComponents.push(text_4);
    
    exp_endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function exp_endRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'exp_end' ---
    // get current time
    t = exp_endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *key_resp_6* updates
    if (t >= 0 && key_resp_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_6.tStart = t;  // (not accounting for frame time here)
      key_resp_6.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_6.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_6.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_6.clearEvents(); });
    }
    
    if (key_resp_6.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_6.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_6_allKeys = _key_resp_6_allKeys.concat(theseKeys);
      if (_key_resp_6_allKeys.length > 0) {
        key_resp_6.keys = _key_resp_6_allKeys[_key_resp_6_allKeys.length - 1].name;  // just the last key pressed
        key_resp_6.rt = _key_resp_6_allKeys[_key_resp_6_allKeys.length - 1].rt;
        key_resp_6.duration = _key_resp_6_allKeys[_key_resp_6_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *text_4* updates
    if (t >= 0 && text_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_4.tStart = t;  // (not accounting for frame time here)
      text_4.frameNStart = frameN;  // exact frame index
      
      text_4.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    exp_endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function exp_endRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'exp_end' ---
    exp_endComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('exp_end.stopped', globalClock.getTime());
    key_resp_6.stop();
    // the Routine "exp_end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  // Run 'End Experiment' code from hide_mouse
  document.body.style.cursor='auto';
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
